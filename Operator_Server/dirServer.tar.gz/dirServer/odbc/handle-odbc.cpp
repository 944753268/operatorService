#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "global.h"



using namespace std;
//odbc
/* 检测返回代码是否为成功标志，当为成功标志返回TRUE，否则返回FALSE */
#define RC_SUCCESSFUL(rc)  ((rc) == SQL_SUCCESS || (rc) == SQL_SUCCESS_WITH_INFO)
/* 检测返回代码是否为失败标志，当为失败标志返回TRUE，否则返回FALSE */
#define RC_NOTSUCCESSFUL(rc) (!(RC_SUCCESSFUL(rc)))


#define ROW_ARRAY_SIZE 100

SQLHENV      henv;  /* 环境句柄 */
SQLHDBC      hdbc;  /* 连接句柄 */
SQLHSTMT     hsmt;  /* 语句句柄 */
SQLHSTMT     hsmtread;  /* 语句句柄 */
SQLHSTMT     hsmtinsert;  /* 语句句柄 */
//SQLHSTMT     hsmtaddusr;  /* 语句句柄 */
//SQLHSTMT     hsmtdelusr;  /* 语句句柄 */
//SQLHSTMT     hsmtupdate;  /* 语句句柄 */


static char sktipbuf[] = "192.168.2.249";
static char vpnipbuf[] = "192.168.2.244";
//static int handle_recordID; 
static int odbc_reconnect_flag=0;



bool checkIp(char *str)//a rough check
{
	int dot_count = 0;
	int num_count = 0;
	int num_val = 0;
	while((*str))
	{
		if((*str) != '.')
		{
			if((*str) <= '9' && (*str) >= '0')
			{
				++ num_count;
				num_val = num_val * 10 + (*str) - '0';
			}
			else
				return false;
		}
		else
		{
			++ dot_count;
			if(num_count < 1 || num_count > 4 || num_val < 0 || num_val >255)
				//check if the current segment is 1~3 numbers
				return false;
			num_count = 0;
			num_val = 0;
		}
		++ str;
	}
	if(dot_count != 3)
		return false;
	return true;
}

int get_dmserver_dsn_usrname_passwd(char *resdsn, char *resname, char *respasswd)
{
	FILE *fp;
	char tmpValue[32];
	char tmpbuf[256];
	int tlen, len;
	char *pos1, *pos2;

	//	fp=fopen("./dirServer.conf", "r");
	fp=fopen("/etc/dirServer.conf", "r");
	if (fp != NULL)
	{
		while ((fgets(tmpbuf, 255, fp)) != NULL)
		{
			tlen = strlen(tmpbuf);
			if(tmpbuf[tlen - 1] == '\n')  tmpbuf[tlen - 1]='\0';

			if((pos1=strstr(tmpbuf, "[")) != NULL)
			{
				pos1 += 1;
				pos2 = strstr(pos1, "]");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resdsn, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "username=")) != NULL)
			{
				pos1 += 9; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resname, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "passwd=")) != NULL)
			{
				pos1 += 7; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(respasswd, tmpValue);
				break;
			}
		}

		fclose(fp);
		fp=NULL;
	}
	else
		print_data("open /etc/dirServer.conf failed \n");

	return 0;
}

void initJubing()
{
	char dsn[32];
	char usrname[32];
	char passwd[32];
	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);

	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);


}

void endJubing(){
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
}

void initOdbc(void)
{
	char dsn[32];
	//char ip[16];
	//char port[32];
	char usrname[32];
	char passwd[32];

	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);
	print_data("dsn=%s, usrname=%s, passwd=%s\n", dsn, usrname, passwd);

	/* 申请一个环境句柄  */
	SQLAllocHandle(SQL_HANDLE_ENV, NULL, &henv);
	/* 设置环境句柄的ODBC版本  */
	SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER);
	/* 申请一个连接句柄  */
	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//SQLConnect(hdbc, (SQLCHAR *)"DMSERVER", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	/* 申请一个语句句柄  */
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtaddusr);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtdelusr);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtupdate);
}


/*******************************************************************/
/*********************数据库没有记录，插入默认的一条**********************/
/*******************************************************************/
void insert_mysql_default_record(char *in_pid, char *in_pos)
{
	char cmdbuf[256] ;
	SQLRETURN rc;

	sprintf( cmdbuf, "INSERT INTO dir_%s_list SET product_id='%s',position='%s',sktserver_ip='%s',vpnserver_ip='%s';",\
			in_pos, in_pid, in_pos, sktipbuf, vpnipbuf);
	print_data("%s\n", cmdbuf);

	rc = SQLExecDirect( hsmtinsert, (SQLCHAR *)cmdbuf, SQL_NTS);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		print_data("SQLExecDirect odbc_reconnect_flag!\n");
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		print_data("SQLExecDirect error!\n");
		return;
	}
	print_data("写入MySQL成功\n");


	SQLCloseCursor(hsmtinsert);
}


/*************************************************************/
/*******************查询服务器的sktip, vpnip地址************************/
/*************************************************************/
void get_sktserver_vpnserver_ip(char* in_pid, char* in_pos, char* out_sktip, char* out_vpnip)
{
	unsigned int i;
	char cmdbuf[256];

	struct dir_ip {
		SQLCHAR productID[32];
		SQLLEN productIDInd;
		SQLCHAR position[32];  //省名、自治区名、直辖市名
		SQLLEN positionInd;
		SQLCHAR sktServerIp[24];
		SQLLEN sktServerIpInd;
		SQLCHAR vpnServerIp[24];
		SQLLEN vpnServerIpInd;
	};



	/**************************************************************/
	/*******************获取skt服务器ip、vpnfwq的ip的操作*****************************/
	/**************************************************************/
	struct dir_ip OrderInfoArray[ROW_ARRAY_SIZE];
	SQLUINTEGER NumRowsFetched;
	SQLUSMALLINT RowStatusArray[ROW_ARRAY_SIZE];
	SQLRETURN rc;


	sprintf(cmdbuf, "select product_id,position,sktserver_ip,vpnserver_ip from dir_%s_list where product_id='%s';", in_pos, in_pid);
	//sprintf(cmdbuf, "select product_id,position,sktserver_ip,vpnserver_ip from dir_guangdong_list;");
	print_data("%s\n", cmdbuf);
	SQLPrepare(hsmt,(SQLCHAR *)cmdbuf, SQL_NTS);

	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_BIND_TYPE,(SQLPOINTER *)sizeof(dir_ip),0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_ARRAY_SIZE,(SQLPOINTER *)ROW_ARRAY_SIZE,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_STATUS_PTR,RowStatusArray,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROWS_FETCHED_PTR,&NumRowsFetched,0);

	SQLBindCol(hsmt,1,SQL_C_CHAR,OrderInfoArray[0].productID,sizeof(OrderInfoArray[0].productID),&OrderInfoArray[0].productIDInd);
	SQLBindCol(hsmt,2,SQL_C_CHAR,OrderInfoArray[0].position,sizeof(OrderInfoArray[0].position),&OrderInfoArray[0].positionInd);
	SQLBindCol(hsmt,3,SQL_C_CHAR,OrderInfoArray[0].sktServerIp,sizeof(OrderInfoArray[0].sktServerIp),&OrderInfoArray[0].sktServerIpInd);
	SQLBindCol(hsmt,4,SQL_C_CHAR,OrderInfoArray[0].vpnServerIp,sizeof(OrderInfoArray[0].vpnServerIp),&OrderInfoArray[0].vpnServerIpInd);

	rc=SQLExecute(hsmt);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}

	int record_number=0;
	while (( rc = SQLFetchScroll(hsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	{
		for (i = 0 ;i< NumRowsFetched; i++ ) 
		{
			if (RowStatusArray[ i ] == SQL_ROW_SUCCESS||RowStatusArray[i] == SQL_ROW_SUCCESS_WITH_INFO ) 
			{

				record_number++;
				if (OrderInfoArray[i].productIDInd == SQL_NULL_DATA)//2
					print_data("NULL");
				else
					print_data("%s\t " ,  OrderInfoArray[i].productID);

				if (OrderInfoArray[i].positionInd == SQL_NULL_DATA)//2
					print_data("NULL");
				else
					print_data("%s\t " ,  OrderInfoArray[i].position);

				if (OrderInfoArray[i].sktServerIpInd == SQL_NULL_DATA)//2
					print_data("NULL");
				else
					print_data("%s\t " ,  OrderInfoArray[i].sktServerIp);

				if (OrderInfoArray[i].vpnServerIpInd == SQL_NULL_DATA)//2
					print_data("NULL");
				else
					print_data("%s\t " ,  OrderInfoArray[i].vpnServerIp);

				print_data("\n\n");

				/*******************获取操作的表名**************************/
				strcpy(out_sktip, (char *)OrderInfoArray[i].sktServerIp);
				strcpy(out_vpnip, (char *)OrderInfoArray[i].vpnServerIp);

			}
		}
	}

	if(record_number == 0)
	{
		strcpy(out_sktip, sktipbuf);
		strcpy(out_vpnip, vpnipbuf);
		print_data("进入insert into...\n");
		insert_mysql_default_record(in_pid, in_pos);
	}   

	SQLCloseCursor(hsmt);
}



void endOdbc(void)
{
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtaddusr);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtdelusr);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtupdate);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	/* 释放环境句柄  */
	SQLFreeHandle(SQL_HANDLE_ENV, henv);
}


