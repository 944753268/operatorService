/******************************************************
  THIS IS MADE BY:LISHELIN
  E-MAIL:lishelin0505@163.com
CREATE:2015-04-03 FIRST
DECLARE:THIS IS FOR THE DEVICE OF 805AE-1 OF NEWABEL
COMPANY URL:WWW.NEWABEL.COM
 ******************************************************/
#ifndef global_H
#define global_H

extern int do_exit;
//extern struct send_data odbcData, eventData;
//extern int deviceListNum;
//extern struct device_list deviceList[1024];

#define SQL_RET_NULL 0X0001
#define SQL_RET_ERR 0X0002
#define SQL_RET_WRITE 0X0004
#define SQL_RET_READ 0X0008


enum msg_handle{
	MSG_NULL=0,                 //0 
	/******目录服务器消息******/
	MSG_RECEIVE_DIRECTORY_DATA,    
	MSG_SEND_DIRECTORY_DATA,    
	/******状态服务器消息******/
	MSG_RECEIVE_STATUS_DATA,    
	MSG_SEND_STATUS_DATA,    
	/******用户信息服务器消息******/
	MSG_RECEIVE_USER_INFO_DATA,    
	MSG_SEND_USER_INFO_DATA,    
	MSG_MAX,
};
extern int msg_device;



enum status_handle{
	STATUS_ODBC_NULL=0x4000,
	STATUS_ODBC_GET_SERVER_ADDRESS,
	STATUS_ODBC_SET_SERVER_ADDRESS,
	STATUS_ODBC_GET_PRODUCT_STATUS,
	STATUS_ODBC_SET_PRODUCT_STATUS,
	STATUS_ODBC_GET_USER_INFO,
	STATUS_ODBC_SET_USER_INFO,
	STATUS_ODBC_MAX,
};
extern enum status_handle status_odbc;


/*
struct send_data{
	int len;
	unsigned char data[256];
	int type;
};
*/



void get_sktserver_vpnserver_ip(char* in_pid, char* in_pos, char* out_sktip, char* out_vpnip);

void print_data(const char *fmt,...);
//int wait_odbc_timeOut(int second);
void initOdbc(void);
//void * process_handleOdbc(void *parg);
void * process_handleThrift(void *parg);
//int send_odbc_message(status_handle status, int datalen, unsigned char *data, int devtype);
//void exit_thrift(void);
void endOdbc(void);

#endif
