struct Dirip {
	1: string product_id,
	2: string position,
	3: string sktserver_ip,
	4: string vpnserver_ip,
}
service DiripService{
	void put(1:	Dirip dirip),
	Dirip get(
			 1:	string product_id,
			 2:	string position,
			 )
}

