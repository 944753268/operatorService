/*****************************************/
/****************jason_modify*************/
#include <string>  
#include <iostream>   
#include "DiripService.h"    
#include <config.h>    
#include "global.h"
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>
#include <thrift/concurrency/ThreadManager.h>  
#include <thrift/concurrency/PosixThreadFactory.h>  
#include <thrift/server/TThreadPoolServer.h>  
#include <thrift/server/TThreadedServer.h>  
#include <thrift/server/TNonblockingServer.h>  
#include <server/TThreadPoolServer.h>
#include <server/TThreadedServer.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>    
#include <transport/TServerSocket.h>    
#include <transport/TBufferTransports.h>    
#include <concurrency/ThreadManager.h>    
#include <concurrency/PosixThreadFactory.h>    
#include <server/TThreadPoolServer.h>    
#include <server/TThreadedServer.h>    

#define  THREAD_POOL_SERVER 1

using namespace ::apache::thrift;    
using namespace ::apache::thrift::protocol;    
using namespace ::apache::thrift::transport;    
using namespace ::apache::thrift::server;    
using namespace ::apache::thrift::concurrency;    

using boost::shared_ptr;  
using namespace std;   


char output_sktServerIp[48];
char output_vpnServerIp[48];

class DiripServiceHandler : virtual public DiripServiceIf {
	public:
		DiripServiceHandler() {
			// Your initialization goes here
		}

		void put(const Dirip& dirip) {
			// Your implementation goes here
			print_data("调用put方法\n");
		}

		void get(Dirip& _return, const std::string& product_id, const std::string& position) {
			string pid=product_id.c_str();
			string pos=position.c_str();
			char current_productId[32];
			char current_position[32];


			/************************************************************/
			/*****************根据id、位置查询mysql数据库******************/
			/************************************************************/
			strcpy(current_productId, pid.c_str());
			strcpy(current_position, pos.c_str());
			if(strlen(current_productId) < 14) 
				return;
			print_data("current product_id= %s\n", current_productId);
			print_data("current position= %s\n", current_position);	
			output_sktServerIp[0] = '\0';
			output_vpnServerIp[0] = '\0';
			get_sktserver_vpnserver_ip(current_productId, current_position, output_sktServerIp, output_vpnServerIp);


			/************************************************************/
			/*****************返回数据库查询结果******************/
			/************************************************************/
			_return.product_id = current_productId;  
			_return.position = current_position;  
			_return.sktserver_ip = output_sktServerIp;
			_return.vpnserver_ip = output_vpnServerIp;  

			/*
			   _return.product_id = "U03Saabbccddeeff";  
			   _return.position = "云南省";  
			   _return.sktserver_ip = "193.26.97.5";  
			   _return.vpnserver_ip = "195.36.124.87";  
			   print_data("调用get方法\n");
			 */
		}

};

//int main(int argc, char **argv) {
void * process_handleThrift(void *parg)
{

	int port = 19090;
	shared_ptr<DiripServiceHandler> handler(new   DiripServiceHandler());    
	shared_ptr<TProcessor> processor(new DiripServiceProcessor(handler));  

#ifdef THREAD_POOL_SERVER

	shared_ptr<TProtocolFactory> protocolFactory(new TCompactProtocolFactory());    
	shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());    
	shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));    

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	print_data("start dir server...\n");    

	TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);    
	server.serve();    

#else	
	shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start advert server...\n");    

	TNonblockingServer server(processor,protocolFactory,port,threadManager);
	server.serve();    

#endif
	return NULL;
}

