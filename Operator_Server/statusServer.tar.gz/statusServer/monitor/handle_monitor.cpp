//#######lin_modify#######
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <vector>
#include "global.h"

using namespace std;

//struct file_vect
//{
//	string name;
//	int flag;
//};
//
////static vector<string> vectors;
//static vector<file_vect> vectors;
//
//static int vector_size = 0;


void * write_pid_file(Status *sta)
{

	FILE* fp;

	char cmdbuf[256];
	char filename[256];
	int write_length = 0;
//	struct file_vect fv;
	string realFileName;
	int file_exsit_flag = 0;

	if(! strcmp(sta->firmware_version.c_str(), "OK"))
		sprintf( cmdbuf, "OK\n");
	else
		sprintf( cmdbuf,"product_id='%s',time='%s',position='%s',network_status=%s,cloud_status=%s,control_status=%s,\
				firmware_version='%s',fault_code='%s'\n",\
				sta->product_id.c_str(), sta->time.c_str(),sta->position.c_str(), sta->network_status.c_str(), sta->cloud_status.c_str(),\
				sta->control_status.c_str(), sta->firmware_version.c_str(), sta->fault_code.c_str());

	sprintf(filename,"/root/data/input/%s_%s_status",sta->position.c_str(),sta->product_id.c_str());
	//sprintf(filename,"/home/xxp/data/input/%s_%s_status",sta->position.c_str(),sta->product_id.c_str());
	//	sprintf(filename,"/home/xxp/data/xxp/%s_%s",sta->product_id.c_str(),sta->position.c_str());
//	realFileName = sta->position+"_"+sta->product_id+"_status";
//	fv.name = realFileName;
//	fv.flag = 0;
//
//	//if(access(filename,0) == -1)
//	for(vector<file_vect>::iterator it = vectors.begin(); it != vectors.end(); it++)
//	{
//		if(!strcmp((*it).name.c_str(), realFileName.c_str()))
//		{
//			if((*it).flag == 1)
//				(*it).flag = 0;
//			file_exsit_flag =1;
//			break;
//		}
//	}
//
//	if(file_exsit_flag == 0) 
//	{
//		vectors.push_back(fv);
//		vector_size++;
//	}
//	//	else if(vector_size == 0)
//	//	{
//	//		vector_size++;
//	//	}


	fp=fopen(filename,"a+"); //文件创建和追家
	if(fp != NULL)  
	{  
		write_length = fwrite(cmdbuf, 1,strlen(cmdbuf), fp);  
		print_data("write_length = %d\n", write_length);  
	}

	fclose(fp);  
	fp = NULL;  
	return 0;
}

//int getFiles( string path, vector<file_vect>& file_names )
//{
//	DIR *dp;
//	struct dirent *dirp;
//	struct file_vect ft;
//
//	if((dp=opendir(path.c_str()))==NULL){
//		perror("opendir error");
//		exit(1);
//	}   
//
//	while((dirp=readdir(dp))!=NULL){
//		if((strcmp(dirp->d_name,".")==0)||(strcmp(dirp->d_name,"..")==0))
//			continue;
//
//		ft.name = dirp->d_name;
//		ft.flag = 0;
//		//	sprintf(tmpbuf, "%s/%s", path.c_str(), dirp->d_name);
//		//file_names.push_back(dirp->d_name);
//		file_names.push_back(ft);
//		//printf("%6d:%-19s %5s\n",dirp->d_ino,dirp->d_name,(dirp->d_type==DT_DIR)?("(DIR)"):(""));
//	}   
//	closedir(dp);
//
//
//	for(vector<file_vect>::iterator it = file_names.begin(); it != file_names.end(); it++)
//	{   
//		//cout<<(*it).name<<endl;
//	}   
//
//	return 0;
//}
//
//
//void * process_monitorFile(void *parg)
//{
//	/**************监控文件有没有timeout 90s**************/
//	/***************首先要遍历保存p_id文件夹，取得相关name，也就是P_ID*******************/
//	/***************stat是描述一个linux系统文件系统中的文件属性的结构********************/
//	/***************stat（file,&st）返回文件相关属性，如果不存在返回0********************/
//	/****st.st_mtime返回文件最后修改时间，可以ctime(&st.st_atime)把时间格式变成字符******/
//	/***************time_t类型表示最迟时间，time(&t)取得当前时间秒数*********************/
//	int i, tmp_size;
//	struct stat st;
//	char filePath[56] = "/root/data/input";
//	//    char filePath[] = "/home/xxp/data/xxp";
//	char tmpbuf[128];
//	char cmdbuf[256];
//	string name ;
//	time_t t;
//	t = time(&t);
//	char cdate[50] ;   
//	struct tm *p;
//	int a,b;
//
//	while(1)
//	{
//		tmp_size = vectors.size();
//		if(vector_size != tmp_size)
//		{
//			//vectors.clear();
//			getFiles(filePath, vectors );
//			tmp_size = vectors.size(); 
//			vector_size = tmp_size;
//		}
//		/*
//		////获取该路径下的所有文件
//		getFiles(filePath, vectors );
//		int size = vectors.size();
//		 */
//
//		for (i=0; i<tmp_size; i++)
//		{
//			print_data("%d\n",vectors[i].flag);
//			if(vectors[i].flag == 1)
//
//				continue;
//
//			sprintf(tmpbuf, "%s/%s",filePath, vectors[i].name.c_str());
//			print_data("%s\n",tmpbuf);
//			name = vectors[i].name.c_str();
//
//			if (0 != stat(tmpbuf, &st)){
//				print_data(" 无法获取文件相关属性\n");
//				vectors.clear();
//				vector_size =0;
//				break;
//			}
//			//print_data( "该文件的最后修改时间为：%d\n", st.st_mtime);
//
//			time(&t); /*获得time_t结构的时间，UTC时间*/
//			p = localtime(&t); /*转换为struct tm结构的UTC时间*/
//			//print_data( "最后修改时间：%d\n", ctime(&st.st_atime));
//			//print_data( "当前时间：%d\n", t);
//			//print_data( "相差时长：%d秒\n", ( t - st.st_mtime ));
//			print_data( "相差时长：%d天\n", ( t - st.st_mtime )/86400);
//
//
//
//			//cout << "最后修改时间：" << ctime(&st.st_atime) <<endl;
//			//cout << "当前时间：" << t <<  endl; 
//			//cout << "相差时长：" <<( t - st.st_mtime ) <<"秒"<< endl;
//			//cout << "相差时长：" <<( t - st.st_mtime )/86400 <<"天"<< endl;
//			if(t-st.st_mtime >= 90 && t-st.st_mtime<100)
//			{
//
//				Status *check_status = new Status();
//				cdate[0] ='\0';
//				time(NULL); /*获得time_t结构的时间，UTC时间*/
//				p = localtime(&t); /*转换为struct tm结构的UTC时间*/
//
//				strftime(cdate, 50, "%Y-%m-%d %H:%M:%S", p); 
//				check_status->time = cdate;	
//				check_status->position =name.substr(0,name.find("_"));
//				a = name.find("_")+1;
//				b = name.rfind("_")-a;
//				check_status-> product_id = name.substr(a,b);
//				check_status->network_status = -1;
//				/*******************************************************************/
//				/****************************更新数据库联网状态********************/
//				/*******************************************************************/
//				update_mysql_network_status(check_status);
//
//				sprintf(cmdbuf, "cp -rf %s /root/data/output", tmpbuf);
//				//				sprintf(cmdbuf, "cp -rf %s /home/xxp/data/output", tmpbuf);
//				print_data("%s\n", cmdbuf);
//				system(cmdbuf);
//				sprintf(cmdbuf, "echo > %s", tmpbuf);
//				system(cmdbuf);
//
//				vectors[i].flag = 1;
//				delete check_status;
//			}
//		}
//
//		sleep(10);
//	}
//
//
//
//	/*************如果timeout，就odbc写数据库断线**************/
//
//
//
//
//
//
//
//	return NULL;
//}

