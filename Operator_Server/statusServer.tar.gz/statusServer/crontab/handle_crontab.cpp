//#######lin_modify#######
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <dirent.h>
#include <vector>
#include "global.h"

using namespace std;

static char currhour[8];
static char currmin[8];
static char currsec[8];
static vector<string> vectors;

int get_current_time(char *hour, char *min, char *sec)
{
	FILE *fp = NULL;
	char tmpbuf[255];
	char * pos1;

	system("date '+%T' > /tmp/time.info");

	fp = fopen("/tmp/time.info", "r");
	if (fp != NULL) {
		if ((fgets(tmpbuf, 255, fp)) != NULL) {

			pos1 = tmpbuf;
			strncpy(hour, pos1, 2);
			hour[2]='\0';

			pos1 += 3;
			strncpy(min, pos1, 2);
			min[2]='\0';

			pos1 += 3;
			strncpy(sec, pos1, 2);
			sec[2]='\0';

			print_data("hour=%s, min=%s, sec=%s \n", hour, min, sec);
		}

		fclose(fp);
	}

	return 0;
}


int getFiles( string path, vector<string>& file_names )
{
	DIR *dp;
	struct dirent *dirp;
	//char tmpbuf[255];

	if((dp=opendir(path.c_str()))==NULL){
		perror("opendir error");
		exit(1);
	}   

	while((dirp=readdir(dp))!=NULL){
		if((strcmp(dirp->d_name,".")==0)||(strcmp(dirp->d_name,"..")==0))
			continue;

	  //  sprintf(tmpbuf, "%s/%s", path.c_str(), dirp->d_name);
	    file_names.push_back(dirp->d_name);
	}   
	closedir(dp);


	for(vector<string>::iterator it = file_names.begin(); it != file_names.end(); it++)
	{   
		print_data("%s\n", (*it).c_str());
	}   

	return 0;
}



int is_file_empty(char *filename)
{
	FILE *fp = NULL;
	int len =1;

	if((fp=fopen("FileName","rb")) !=NULL)   
	{
		fseek(fp,0L,SEEK_END);   
		len=ftell(fp);   
	}

	return len;
}


int do_position_file(char *pos)
{
	char cmdbuf[256];
	char finame[256];
	char rename[256];

	system("rm -rf /root/data/output_tmp/*");
	sprintf(cmdbuf,"cp -f /root/data/input/%s_* /root/data/output_tmp", pos);

	system(cmdbuf);

	//*****//
	//*****//
	vectors.clear();
	getFiles("/root/data/output_tmp", vectors );
	for(vector<string>::iterator it = vectors.begin(); it != vectors.end(); it++)
	{   
		
		sprintf(rename,"echo  > %s%s","/root/data/input/",(*it).c_str());
		system(rename);
		sprintf(finame,"%s%s","/root/data/output_tmp/",(*it).c_str());
		
		if(is_file_empty(finame) == 0)
			unlink(finame); 
	}   

	//*****//
	//*****//

	system("cp -f /root/data/output_tmp/* /root/data/output");
	
	system("rm -rf /root/data/output_tmp/*");
	return 0;
	
}



void * process_crontab(void *parg)
{
	int timevalue = 0;
	char position[36];
	string arr[]={"anhui","aomen","beijing","chongqing","fujian","gansu","guangdong","guangxi","guizhou","hainan","hebei","heilongjiang",
	"henan","hubei","hunan","jiangsu","jiangxi","jilin","jinxi","liaoning","neimenggu","ningxia","none","qinghai","shandong",
	"shanghai","shanxi","sichuan","taiwan","tianjin","xianggang","xinjiang","xizang","yunnan","zhejiang"};
    size_t s_count=sizeof(arr)/sizeof(string);
	vector<string> ivec(arr,arr+s_count);
	

	while(1)
	{
		get_current_time(currhour, currmin, currsec);
		timevalue = atoi(currhour)*3600 + atoi(currmin)*60 + atoi(currsec);
		//if((timevalue < 24*3600-60*10) && (timevalue > 60*10))
		if((timevalue > 0) && (timevalue < 60*12 )){
			for(vector<string>::iterator it = ivec.begin(); it != ivec.end(); it++)
		    {
				
				strcpy(position, (*it).c_str());
				do_position_file(position);
				sleep(5*60);
			}

		}
		else
		{
			sleep(10*60);
		}
	}


	/*************如果timeout，就odbc写数据库断线**************/

	return NULL;
}

