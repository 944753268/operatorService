/*****************************************/
/****************jason_modify*************/
#include <string>  
#include <iostream>   
#include <config.h>    
#include "StatusService.h"
#include "global.h"
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>
#include <thrift/concurrency/ThreadManager.h>  
#include <thrift/concurrency/PosixThreadFactory.h>  
#include <thrift/server/TThreadPoolServer.h>  
#include <thrift/server/TThreadedServer.h>  
#include <thrift/server/TNonblockingServer.h>  
#include <server/TThreadPoolServer.h>
#include <server/TThreadedServer.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>    
#include <transport/TServerSocket.h>    
#include <transport/TBufferTransports.h>    
#include <concurrency/ThreadManager.h>    
#include <concurrency/PosixThreadFactory.h>    
#include <server/TThreadPoolServer.h>    
#include <server/TThreadedServer.h>    

#define  THREAD_POOL_SERVER 1

using namespace ::apache::thrift;    
using namespace ::apache::thrift::protocol;    
using namespace ::apache::thrift::transport;    
using namespace ::apache::thrift::server;    
using namespace ::apache::thrift::concurrency;    

using boost::shared_ptr;  
using namespace std;   


int check_isnot_char_digit(const char * strbuf)
{
	const char *s = strbuf;
	int i, len=strlen(strbuf);
	int isnot_flag=0;

	for(i=0; i<len; i ++) 
	{   
		if(s[i]>='0' && s[i]<='9')
			continue;
		else if(s[i]>='a' && s[i]<='z')
			continue;
		else if(s[i]>='A' && s[i]<='Z')
			continue;
		else if(s[i]=='_')
			continue;
		else
		{   
			printf("strbuf=%s, i=%d\n", strbuf, i); 
			isnot_flag = 1;
			break;
		}   
	}   

	return isnot_flag;
}


class StatusServiceHandler : virtual public StatusServiceIf {
	public:
		StatusServiceHandler() {
			// Your initialization goes here
		}

		void put(const Status& status) {
#if 1
			/**************************************************************/	
			/*******************获取status结构体***************************/	
			/**************************************************************/	
			print_data("--------put--------\n");
			Status *current_status = new Status();

			current_status->time = status.time;
			current_status->product_id = status.product_id;
			current_status->position = status.position;
			current_status->firmware_version = status.firmware_version;
			current_status->network_status = status.network_status;
			current_status->cloud_status = status.cloud_status;
			current_status->control_status = status.control_status;
			current_status->fault_code = status.fault_code;
			current_status->openvpn_ip = status.openvpn_ip;
			current_status->address = status.address;
			 if(atoi((current_status->network_status).c_str()) == 0)
           		 {   
						string net="1";
                		print_data("Warning: status client C process deal...... !\n");
                		current_status->network_status = net;
            		 }   


			print_data("pid= %s,  position= %s, address= %s, network=%s \n", (current_status->product_id).c_str(), (current_status->position).c_str(),(current_status->address).c_str(),(current_status->network_status).c_str());
			if(((current_status->product_id).length() < 3) || ((current_status->position).length() < 3))
				return;
			if(check_isnot_char_digit((current_status->product_id).c_str()) || check_isnot_char_digit((current_status->position).c_str()))
				return;

			//	if(!strncmp(current_status->position.c_str(), "OK", 2))
			if(!strncmp(current_status->firmware_version.c_str(), "OK", 2))
			{
				print_data("put OK !\n");
			}
			else
			{
				/************************************************************/
				/******将statusClient采集的status信息传到mysql数据库中保存,利用odbc写入mysql*****/
				/************************************************************/
				update_mysql_run_status(current_status);
			}

			write_pid_file(current_status);

			/*****************************************/
			/*****************************************/
			/**********1.获取当前的系统时间*******************************/
			/**********2.将时间与数据写到文件中*******************************/
			/*****************************************/
			/*****************************************/
			/****************************************/

			delete current_status;
#endif
			//printf("调用了put方法\n");
		}

		void get(Status& _return, const std::string& product_id, const std::string& position) {
			string pid=product_id.c_str();
			string pos=position.c_str();
			print_data("-----get-------\n");

			char current_productId[32];
			char current_position[32];
			char output_control_status[32];


			/***********************************************************/
			/*****************根据id、位置查询mysql数据库******************/
			/************************************************************/
			strcpy(current_productId, pid.c_str());
			strcpy(current_position, pos.c_str());
#if 1

			/************************************************************/
			/*****************查询数据库control_status结果******************/
			/************************************************************/
			if((strlen(current_position) > 3) && (strlen(current_productId) > 3))
			{
				get_mysql_control_status(current_productId, current_position, output_control_status);
			}

#endif
			/*****************返回get结果******************/
			_return.product_id = current_productId;
			_return.position = current_position;
			_return.control_status = output_control_status;
			_return.__isset.control_status = true;
			//			printf("调用了get方法\n");
		}
};

//int main(int argc, char **argv) {
void * process_handleThrift(void *parg)
{
	int port = 19091;

	shared_ptr<StatusServiceHandler> handler(new StatusServiceHandler());
	shared_ptr<TProcessor> processor(new StatusServiceProcessor(handler));
#ifdef THREAD_POOL_SERVER

	shared_ptr<TProtocolFactory> protocolFactory(new TCompactProtocolFactory()); 
	shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());  
	shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	print_data("start status server...\n");    

	TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);    
	server.serve();
#else
	shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start advert server...\n");    

	TNonblockingServer server(processor,protocolFactory,port,threadManager);
	server.serve();    
#endif
	return NULL;
}

