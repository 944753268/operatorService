struct Status{
	1: required string time,
	2: required string product_id,
	3: required string position,
	4: optional string firmware_version,
	5: optional string  network_status,
	6: optional string  cloud_status,
	7: optional string  control_status,
	8: optional string fault_code,
	9: optional string openvpn_ip,
	10: optional string address,
}

service StatusService{
	void put(1:	Status status),
	Status get(
			 1:	string product_id,
			 2:	string position,
			 )
}

