#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "global.h"


using namespace std;
//odbc
/* 检测返回代码是否为成功标志，当为成功标志返回TRUE，否则返回FALSE */
#define RC_SUCCESSFUL(rc)  ((rc) == SQL_SUCCESS || (rc) == SQL_SUCCESS_WITH_INFO)
/* 检测返回代码是否为失败标志，当为失败标志返回TRUE，否则返回FALSE */
#define RC_NOTSUCCESSFUL(rc) (!(RC_SUCCESSFUL(rc)))


#define ROW_ARRAY_SIZE 100

SQLHENV      henv;  /* 环境句柄 */
SQLHDBC      hdbc;  /* 连接句柄 */
SQLHSTMT     hsmt;  /* 语句句柄 */
SQLHSTMT     hsmtread;  /* 语句句柄 */
SQLHSTMT     hsmtinsert;  /* 语句句柄 */
//SQLHSTMT     hsmtaddusr;  /* 语句句柄 */
//SQLHSTMT     hsmtdelusr;  /* 语句句柄 */
//SQLHSTMT     hsmtupdate;  /* 语句句柄 */


static int odbc_reconnect_flag=0;



int get_dmserver_dsn_usrname_passwd(char *resdsn, char *resname, char *respasswd)
{
	FILE *fp;
	char tmpValue[32];
	char tmpbuf[256];
	int tlen, len;
	char *pos1, *pos2;

	fp=fopen("/etc/statusServer.conf", "r");
	//fp=fopen("./statusServer.conf", "r");
	if (fp != NULL)
	{
		while ((fgets(tmpbuf, 255, fp)) != NULL)
		{
			tlen = strlen(tmpbuf);
			if(tmpbuf[tlen - 1] == '\n')  tmpbuf[tlen - 1]='\0';

			if((pos1=strstr(tmpbuf, "[")) != NULL)
			{
				pos1 += 1;
				pos2 = strstr(pos1, "]");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resdsn, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "username=")) != NULL)
			{
				pos1 += 9; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resname, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "passwd=")) != NULL)
			{
				pos1 += 7; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(respasswd, tmpValue);
				break;
			}
		}

		fclose(fp);
		fp=NULL;
	}
	else
		print_data("open /etc/sktServer.conf failed \n");

	return 0;
}



void initOdbc(void)
{
	char dsn[32];
	//char ip[16];
	//char port[32];
	char usrname[32];
	char passwd[32];

	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);
	print_data("dsn=%s, usrname=%s, passwd=%s\n", dsn, usrname, passwd);

	/* 申请一个环境句柄  */
	SQLAllocHandle(SQL_HANDLE_ENV, NULL, &henv);
	/* 设置环境句柄的ODBC版本  */
	SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER);
	/* 申请一个连接句柄  */
	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//SQLConnect(hdbc, (SQLCHAR *)"DMSERVER", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	/* 申请一个语句句柄  */
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);
	//  SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtaddusr);
	//  SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtdelusr);
	//  SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtupdate);


}

void initJubing()
{
	char dsn[32];
	char usrname[32];
	char passwd[32];
	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);

	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);


}
void endJubing(){
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
}
void endOdbc(void)
{
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);
	//  SQLFreeHandle(SQL_HANDLE_STMT, hsmtaddusr);
	//  SQLFreeHandle(SQL_HANDLE_STMT, hsmtdelusr);
	//  SQLFreeHandle(SQL_HANDLE_STMT, hsmtupdate);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	/* 释放环境句柄  */
	SQLFreeHandle(SQL_HANDLE_ENV, henv);

}


/*******************************************************************/
/*********************更新mysql数据库的产品状态*************************/
/*******************************************************************/
void update_mysql_run_status(Status *sta)
{
	char cmdbuf[256] ;
	//	char cmdbuf1[256] ;
	SQLRETURN rc;

	sprintf( cmdbuf, "UPDATE status_%s_list	SET time='%s',position='%s',network_status=%d,cloud_status=%d,control_status=%d,firmware_version='%s',fault_code='%s',openvpn_ip='%s' WHERE product_id='%s';",\
			sta->position.c_str(), sta->time.c_str(), sta->address.c_str(), atoi(sta->network_status.c_str()), atoi(sta->cloud_status.c_str()),atoi(sta->control_status.c_str()), sta->firmware_version.c_str(), sta->fault_code.c_str(), sta->openvpn_ip.c_str(), sta->product_id.c_str());
	print_data("%s\n", cmdbuf);

	rc = SQLExecDirect( hsmt, (SQLCHAR *)cmdbuf, SQL_NTS);
	print_data("###################update_mysql_run_status, rc=%d############\n", rc);
	if(rc == SQL_INVALID_HANDLE)
	{    
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}    
	else if ( rc != SQL_SUCCESS )
	{
		print_data("SQLExecDirect error!\n");
		return;
	}
	print_data("写入MySQL成功\n");


	SQLCloseCursor(hsmt);
}


/*******************************************************************/
/*********************更新**********************/
/*******************************************************************/
void update_mysql_network_status(Status *sta)
{
	char cmdbuf[256] ;
	SQLRETURN rc;

	sprintf( cmdbuf, "UPDATE status_%s_list SET time='%s', network_status=%d WHERE product_id='%s';", \
			sta->position.c_str(),sta->time.c_str(),atoi(sta->network_status.c_str()), sta->product_id.c_str());
	print_data("%s\n", cmdbuf);

	rc = SQLExecDirect( hsmtread, (SQLCHAR *)cmdbuf, SQL_NTS);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		print_data("SQLExecDirect odbc_reconnect_flag!\n");
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		//cout << "SQLExecDirect error!" << endl ;
		print_data("SQLExecDirect error!\n");
		return;
	}
	print_data("写入MySQL成功\n");


	SQLCloseCursor(hsmtread);
}


/*******************************************************************/
/*********************数据库没有记录，插入默认的一条**********************/
/*******************************************************************/
void insert_mysql_default_record(char *in_pid, char *in_pos)
{
	char cmdbuf[256] ;
	SQLRETURN rc;
	int i=0;
    	sprintf( cmdbuf, "INSERT INTO status_%s_list SET product_id='%s',network_status=%d,cloud_status=%d,control_status=%d;", in_pos, in_pid,i,i,i);

//	sprintf( cmdbuf, "INSERT INTO status_%s_list SET product_id='%s';", in_pos, in_pid);
	print_data("%s\n", cmdbuf);

	rc = SQLExecDirect( hsmtinsert, (SQLCHAR *)cmdbuf, SQL_NTS);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		print_data("SQLExecDirect odbc_reconnect_flag!\n");
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		//cout << "SQLExecDirect error!" << endl ;
		print_data("SQLExecDirect error!\n");
		return;
	}
	print_data("写入MySQL成功\n");


	SQLCloseCursor(hsmtinsert);
}

/*******************************************************************/
/***************************查询control_status状态值************************/
/*******************************************************************/
void get_mysql_control_status(char *in_pid, char *in_pos, char *out_status)
{
	unsigned int i;
	char cmdbuf[256];
	//char sqlInputBuf[32];
	//long sqlInputBufInd;

	struct status_info {
		SQLCHAR pid[32];
		SQLLEN pidInd;
		SQLCHAR position[32];
		SQLLEN positionInd;
		SQLINTEGER controlStatus;
		SQLLEN controlStatusInd;
	};

	/**************************************************************/
	/*******************获取control_status****************************/
	/**************************************************************/
	struct status_info OrderInfoArray[ROW_ARRAY_SIZE];
	SQLUINTEGER NumRowsFetched;
	SQLUSMALLINT RowStatusArray[ROW_ARRAY_SIZE];
	SQLRETURN rc;

	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_BIND_TYPE,(SQLPOINTER *)sizeof(status_info),0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_ARRAY_SIZE,(SQLPOINTER *)ROW_ARRAY_SIZE,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_STATUS_PTR,RowStatusArray,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROWS_FETCHED_PTR,&NumRowsFetched,0);

	sprintf( cmdbuf, "SELECT control_status from status_%s_list WHERE product_id='%s';", in_pos, in_pid);
	print_data("%s\n", cmdbuf);

	SQLPrepare(hsmt,(SQLCHAR *)cmdbuf, SQL_NTS);

	SQLBindCol(hsmt,1,SQL_C_ULONG,&OrderInfoArray[0].controlStatus,sizeof(OrderInfoArray[0].controlStatus),&OrderInfoArray[0].controlStatusInd);
	rc=SQLExecute(hsmt);
	print_data("###################get_mysql_control_status, rc=%d, NumRowsFetched=%d ############\n", rc, NumRowsFetched);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return ;
	}

	int record_number=0;
	//while (( rc = SQLFetchScroll(hsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	/********************************************/
	/*********2018-03-23**ping_modify***********/
	/*******************************************/
	if (( rc = SQLFetchScroll(hsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	{
		for (i = 0 ;i< NumRowsFetched; i++ ) 
		{
			if (RowStatusArray[ i ] == SQL_ROW_SUCCESS||RowStatusArray[i] == SQL_ROW_SUCCESS_WITH_INFO ) 
			{
				record_number++;

				if (OrderInfoArray[i].controlStatusInd == SQL_NULL_DATA)//1
					print_data("NULL");
				else
					print_data("%d\n " ,  OrderInfoArray[i].controlStatus);
				print_data("\n\n");
				/*******************获取control_status的值**************************/
				sprintf(out_status,"%d",OrderInfoArray[i].controlStatus);
				print_data("%s of mysql get control_status= %s\n ", in_pid,out_status);
			}
		}
	}

	if(record_number == 0)
	{
		strcpy(out_status,"0");
		insert_mysql_default_record(in_pid, in_pos);
	}

	SQLCloseCursor(hsmt);
}

