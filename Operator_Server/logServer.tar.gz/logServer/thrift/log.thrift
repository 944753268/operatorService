struct  Log{
	1: string name,
	2: string path,
	3: i32 len,
	4: string content,
}

service LogService{
	void upload(1: Log log),
}

