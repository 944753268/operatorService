/*****************************************/
/****************jason_modify*************/
/****************chanfee_modify**********/
#include <string>
#include <iostream>
#include <fstream>

#include <vector>

#include <config.h>
#include <server/TThreadedServer.h>
#include "LogService.h"
#include "global.h"
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>
#include <thrift/concurrency/ThreadManager.h>  
#include <thrift/concurrency/PosixThreadFactory.h>  
#include <thrift/server/TThreadPoolServer.h>  
#include <thrift/server/TThreadedServer.h>  
#include <thrift/server/TNonblockingServer.h>  
#include <server/TThreadPoolServer.h>
#include <server/TThreadedServer.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>    
#include <transport/TServerSocket.h>    
#include <transport/TBufferTransports.h>    
#include <concurrency/ThreadManager.h>    
#include <concurrency/PosixThreadFactory.h>    
#include <server/TThreadPoolServer.h>    
#include <server/TThreadedServer.h>    

#define  THREAD_POOL_SERVER 1

using namespace ::apache::thrift;
using namespace ::apache::thrift::protocol;
using namespace ::apache::thrift::transport;
using namespace ::apache::thrift::server;
using namespace ::apache::thrift::concurrency;

using boost::shared_ptr;
using namespace std;


class LogServiceHandler : virtual public LogServiceIf {
	public:
		LogServiceHandler() {
			// Your initialization goes here
		}


		/**
		 *字符串分割函数
		 */
		std::vector<std::string> split(std::string str,std::string pattern)
		{
			std::string::size_type pos;
			std::vector<std::string> result;
			str+=pattern;//扩展字符串以方便操作
			unsigned int size = str.size();

			for(unsigned int i=0; i<size; i++)
			{
				pos=str.find(pattern,i);
				if(pos < size)
				{
					std::string s=str.substr(i,pos-i);
					result.push_back(s);
					i=pos+pattern.size()-1;
				}
			}
			return result;
		}


		void upload(const Log& log) {

			/***************************************************************/
			/**************************验证接收文件的长度***************************/
			/***************************************************************/
			int length = log.content.length();
			//printf_data("received file length= %d\n", length);
			if(length != log.len)
			{
				print_data("the file upload length error......!\n");
				//return;
			}

			/***************************************************************/
			/**************************获取完整文件名称***************************/
			/***************************************************************/
			//string pathBuf = "/root/data/output" + log.path;
			string pathBuf = "/root/data/output/";
//			string pathBuf = "/home/xxp/data/output/";
			print_data("filelen=%d,  filename=%s\n", log.len, pathBuf.c_str());

			/*********************截取文件名************************/
			std::vector<std::string> nameSplit = split(log.name,"_");


			/***************************************************************/
			/**************************内容输出到文件***************************/
			/***************************************************************/

			/******************需要分割的日志************************/
			print_data("#############robot info: \n");
			print_data("province= %s", nameSplit[1].c_str());
			print_data(" pid= %s", nameSplit[0].c_str());
			if(nameSplit[2] == "runstatus.txt"){
				string pathBuf_1 = pathBuf + nameSplit[1] + "_" + nameSplit[0] + "_runstatus" + "_" + nameSplit[3];
				ofstream ofile(pathBuf_1.c_str()); //建一个文件
				ofile << log.content; //将其写入test.txt 
				ofile.close();
				print_data("upload runstatus.txt ok\n");
			}else if(nameSplit[2] == "system.txt"){
				string pathBuf_2 = pathBuf + nameSplit[1] + "_" + nameSplit[0] + "_system";
				ofstream ofile(pathBuf_2.c_str()); //建一个文件
				ofile << log.content; //将其写入test.txt 
				ofile.close();
				print_data("upload system.txt ok\n");
			}else if(nameSplit[2] == "main.txt"){
				string pathBuf_2 = pathBuf + nameSplit[1] + "_" + nameSplit[0] + "_main";
				ofstream ofile(pathBuf_2.c_str()); //建一个文件
				ofile << log.content; //将其写入test.txt 
				ofile.close();
				print_data("upload main.txt ok\n");
			}else if(nameSplit[2] == "radio.txt"){
				string pathBuf_2 = pathBuf + nameSplit[1] + "_" + nameSplit[0] + "_radio";
				ofstream ofile(pathBuf_2.c_str()); //建一个文件
				ofile << log.content; //将其写入test.txt 
				ofile.close();
				print_data("upload radio.txt ok\n");
			}else if(nameSplit[2] == "events.txt"){
				string pathBuf_2 = pathBuf + nameSplit[1] + "_" + nameSplit[0] + "_events";
				ofstream ofile(pathBuf_2.c_str()); //建一个文件
				ofile << log.content; //将其写入test.txt 
				ofile.close();
				print_data("upload events.txt ok\n");
			}
			print_data("upload ok\n");
		}
};

//int main(int argc, char **argv) {
void * process_handleThrift(void *parg)
{
	int port = 19092;

	shared_ptr<LogServiceHandler> handler(new LogServiceHandler());
	shared_ptr<TProcessor> processor(new LogServiceProcessor(handler));

#ifdef THREAD_POOL_SERVER
	shared_ptr<TProtocolFactory> protocolFactory(new TCompactProtocolFactory());
	shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());
	shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(1000);
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());
	threadManager->threadFactory(threadFactory);
	threadManager->start();
	print_data("start dir server...\n");

	TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);
	server.serve();
#else
	shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start advert server...\n");    

	TNonblockingServer server(processor,protocolFactory,port,threadManager);
	server.serve();    
#endif
	return NULL;
}
