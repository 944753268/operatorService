/******************************************************
  THIS IS MADE BY:LISHELIN
  E-MAIL:lishelin0505@163.com
CREATE:2015-04-03 FIRST
DECLARE:THIS IS FOR THE DEVICE OF 805AE-1 OF NEWABEL
COMPANY URL:WWW.NEWABEL.COM
 ******************************************************/
#ifndef global_H
#define global_H

extern int do_exit;




void print_data(const char *fmt,...);
//void initOdbc(void);
void * process_handleThrift(void *parg);
//void endOdbc(void);

#endif
