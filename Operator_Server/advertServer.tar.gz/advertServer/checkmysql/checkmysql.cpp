/*****************************************/
/****************jason_modify*************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <config.h>
#include "global.h"



void update_mysql_advert_send_flag_status()
{
//	printf("更新数据状态\n");
    query_mysql_endflag();

}


void * process_checkmysql(void *parg)
{
	while(1)
	{
		sleep(60*10);
//		printf("启动监控数据库的程序\n");
		update_mysql_advert_send_flag_status();

	}   

	return NULL;
}

