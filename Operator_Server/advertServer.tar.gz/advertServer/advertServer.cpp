/*****jason_modify*****/
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h> 
#include <time.h> 
#include <sys/time.h> 
#include <sys/stat.h>
#include <iostream>  
#include <sys/socket.h>    
#include <netinet/in.h>    
#include <arpa/inet.h>    
#include <netdb.h>  
#include <vector>
#include <stdarg.h>
#include "global.h"


#define SKT_VERINFO  "advertSever v1.0-2015-04-06"
#define Log_File "/tmp/advertServer.log"
#define FILE_SIZE 1024*1024*10

static pthread_t handleodbc_pid= 0;
static pthread_t handlebase64_pid= 0;
static pthread_t checkmysql_pid= 0;
int printf_debug_seting;
int do_exit = 0;


int init_debug_seting(int* printDebug)
{
	FILE *fp;
	char tmpip[16];
	char tmpbuf[256];
	int tlen, len;
	char *pos1, *pos2;

	fp=fopen("./advertServer.conf", "r");
	if (fp != NULL)
	{   
		while ((fgets(tmpbuf, 255, fp)) != NULL)
		{
			tlen = strlen(tmpbuf);
			if(tmpbuf[tlen - 1] == '\n')  tmpbuf[tlen - 1]='\0';

			if((pos1=strstr(tmpbuf, "printf_debug=")) != NULL)
			{
				pos1 += 13;  
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpip, pos1, len);
				tmpip[len] = '\0';
				*printDebug = atoi(tmpip);
				//printf("\nprintf_debug=%d\n", *printDebug);
				break;
			}
		}

		fclose(fp);
		fp=NULL;
	}
	else
		print_data("open /etc/advertServer.conf failed \n");

	return 0;
}


unsigned long get_file_size(const char *filename)  
{     
	struct stat buf;     
	if(stat(filename, &buf)<0)     
	{     
		return 0;     
	}     
	return (unsigned long)buf.st_size;  
} 

void print_data(const char *fmt,...)
{
	va_list ap;//初始化指向可变参数列表的指针
	char string[1024]=""; 
	va_start(ap,fmt);//将第一个可变参数的地址付给ap，即ap指向可变参数列表的开始
	vsnprintf(string,sizeof(string),fmt,ap);//将参数fmt、ap指向的可变参数一起转换成格式化字符串，放string数组中，其作用同
	va_end(ap); //ap付值为0，没什么实际用处，主要是为程序健壮性

	if(printf_debug_seting == 0)
	{
		if (get_file_size(Log_File) >= FILE_SIZE)//文件大于1M的时候删掉该文件
			remove(Log_File);
		FILE *fp; 
		fp=fopen(Log_File,"a+");
		if (fp==NULL)
		{    
			printf("Open log file is failed!\n");
			return ;    
		}    
		fprintf(fp,"%s", string);
		fclose(fp);
	}
	else
		printf("%s", string);
}

int thread_start(pthread_t *thread_id, void* (*thread_function)(void * ), void * para)
{
	pthread_attr_t attr;
	if (pthread_attr_init(&attr) != 0) {
		return -1; 
	}   
	/*设置线程为全局调度模式*/
	if (pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM) != 0) {
		pthread_attr_destroy(&attr);
		return -1; 
	}   
#if (defined(_SUN_UNIX) || (defined(_AIX_UNIX)))
	if (pthread_create((unsigned int *)thread_id, &attr, thread_function, para) != 0)
#else
		if (pthread_create((pthread_t*)thread_id, &attr, thread_function, para) != 0)
#endif
		{   
			pthread_attr_destroy(&attr);
			return -1; 
		}   
	pthread_attr_destroy(&attr);
	return 0;
}

int exit_all()
{
	//__RET:
	if (handleodbc_pid > 0)
		pthread_join(handleodbc_pid , NULL);
	if (handlebase64_pid > 0)
		pthread_join(handlebase64_pid , NULL);

	endOdbc();

	print_data("advertServer exit program .\n");
	return 0;
}

void __do_clean(int signo) 
{
	exit_all();
	do_exit = 1;
}

int init_all()
{
	init_debug_seting(&printf_debug_seting);
	print_data("\nprintf_debug_seting=%d\n", printf_debug_seting);
	initOdbc();
	sleep(1);

	return 0;
}




int main (int argc, char **argv) 
{
	int c;
	char *g_cfname =  NULL;


	while (1) {
		int option_index = 0;
		static struct option long_options[] = {
			{"file", 1, 0, '-'}, 
			{"version", 0, 0, '-'}, 
			{"help", 0, 0, '-'}, 
			{0, 0, 0, 0}
		};
		c = getopt_long (argc, argv, "f:vh", long_options, &option_index);
		if (c == EOF)
			break;
		switch (c) {
			case '-': 
				{
					switch (option_index) {
						case 0:  // "--file "
							{
								if (optarg ) {
									g_cfname = strdup(optarg);
									print_data("--file %s\n", g_cfname);
								} else {
									fprintf(stderr, "--file no param\n");
									return -1;
								}
								break;
							}
						case 1:  // --version
							{
								print_data ("version %s\n", SKT_VERINFO);
								return 0;
							}
						case 2:
							{
								fprintf(stdout, "Usage %s [f:vh] [param]\n"
										"--file , -f \n	config file name\n"
										"--version, -v\n	version information\n"
										"--help, -h\n	help \n", argv[0] );
								return 0;
							}					
						default :
							fprintf(stderr, "error option_index=%d\n", option_index);
							break;
					}
					break;
				}
			case 'f':
				if (optarg ) {
					g_cfname = strdup(optarg);
					print_data("advertServer -f %s\n", g_cfname);
				} else {
					fprintf(stderr, "-f no param\n");
					return -1;
				}				
				break;
			case 'v':
				print_data ("version %s\n", SKT_VERINFO);
				return 0;

			case 'h':  // help info
				fprintf(stdout, "Usage %s [f:vh] [param]\n"
						"--file , -f \n	config file name\n"
						"--version, -v\n	version information\n"
						"--help, -h\n	help \n", argv[0] );
				return 0;
			default:
				print_data ("?? getopt returned character code 0 %02x ??\n", c);
		}
	}
	if (optind < argc) {
		print_data ("non-option ARGV-elements: ");
		while (optind < argc)
			print_data ("%s ", argv[optind++]);
		print_data ("\n");
	}
	if (NULL == g_cfname) {
		fprintf(stderr, "please input --file , exit\n");
		return -1;
	}

	signal(SIGQUIT, __do_clean);
	signal(SIGTERM, __do_clean);
	signal(SIGINT, __do_clean);
	//signal(SIGALRM, timer_sigal_handler);

	if(daemon(1, 1) <0)
	{
		perror("error daemon ...\n");
		exit(1);
	}

	init_all();


	/* 开启主数据库任务 */
	thread_start(&handleodbc_pid, process_handleOdbc, NULL);

	/* 开启主数据库任务 */
	thread_start(&handlebase64_pid, process_handleBase64, NULL);

	/* 开启主数据库任务 */
	thread_start(&checkmysql_pid, process_checkmysql, NULL);

	/* 开启主处理任务 */
	process_handleThrift(NULL);


	exit_all();

	return 0;
}
