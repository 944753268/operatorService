/******************************************************
  THIS IS MADE BY:LISHELIN
  E-MAIL:lishelin0505@163.com
CREATE:2015-04-03 FIRST
DECLARE:THIS IS FOR THE DEVICE OF 805AE-1 OF NEWABEL
COMPANY URL:WWW.NEWABEL.COM
 ******************************************************/
#ifndef global_H
#define global_H
#include<vector>
using namespace std;
extern int do_exit;
//extern struct send_data odbcData, eventData;
//extern int deviceListNum;
//extern struct device_list deviceList[1024];

#define SQL_RET_NULL 0X0001
#define SQL_RET_ERR 0X0002
#define SQL_RET_WRITE 0X0004
#define SQL_RET_READ 0X0008


struct mysql_advert {
	int id;
	char position[32];
	char name[32];
	int type;
	int number;
	int partnumber;
	char url[128];
	int len;
	char date[32];
	char time[32];
	char pid[32];
	int sendflag;
};  
extern vector<mysql_advert> mysqlAdvert;
extern char ADVERT_HOME[];


void print_data(const char *fmt,...);
//int wait_odbc_timeOut(int second);
void initOdbc(void);
void * process_handleOdbc(void *parg);
void * process_handleThrift(void *parg);
void * process_handleBase64(void *parg);
void * process_checkmysql(void *parg);
//int send_odbc_message(status_handle status, int datalen, unsigned char *data, int devtype);
//void exit_thrift(void);
int encodeBase64(unsigned char *inbuf, int insize, unsigned char *outbuf, int outsize);
void endOdbc(void);
void initJubing();
void endJubing();
void query_mysql_endflag(void);
void update_mysql_sendflag(int id,int flag);


#endif
