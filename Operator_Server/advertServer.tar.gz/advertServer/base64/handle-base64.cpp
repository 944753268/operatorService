/*****************************************/
/****************jason_modify*************/
#include <stdlib.h>  
#include <stdio.h>  
#include <string.h>  
#include <iostream>   
#include <config.h>    
#include "global.h"


//char ADVERT_HOME[]="/home/jason/data/canbot/advert";
char ADVERT_HOME[]="/root/data/canbot/advert";

//char ADVERT_HOME[]="/home/xxp/data/canbot/advert";
int get_general_filenum(char* name);
/*************************************************************************/
/********************************64位编码、解码*****************************************/
/*************************************************************************/
void _encodeBase64(unsigned char *in, unsigned char *out)
{
	static const unsigned char encodeBase64Map[] =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	out[0] = encodeBase64Map[(in[0] >> 2) & 0x3F];
	out[1] = encodeBase64Map[((in[0] << 4) & 0x30) | ((in[1] >> 4) & 0x0F)];
	out[2] = encodeBase64Map[((in[1] << 2) & 0x3C) | ((in[2] >> 6) & 0x03)];
	out[3] = encodeBase64Map[in[2] & 0x3F];
}

int encodeBase64(unsigned char *inbuf, int insize, unsigned char *outbuf, int outsize)
{
	int inpos = 0, outpos = 0;
	while(inpos != insize) {
		if(inpos + 3 <= insize) {
			if(outpos + 4 > outsize)
				return -1;
			_encodeBase64(inbuf + inpos, outbuf + outpos);
			inpos += 3;
			outpos += 4;
		}

		if(insize - inpos == 2) {
			unsigned char tail[3] = {0};
			tail[0] = *(inbuf + inpos);
			tail[1] = *(inbuf + inpos + 1);
			_encodeBase64(tail, outbuf + outpos);
			*(outbuf + outpos + 3) = '=';
			inpos += 2;
			outpos += 4;
		}
		if(insize - inpos == 1) {
			unsigned char tail[3] = {0};
			tail[0] = *(inbuf + inpos);
			_encodeBase64(tail, outbuf + outpos);
			*(outbuf + outpos + 3) = '=';
			*(outbuf + outpos + 2) = '=';
			inpos += 1;
			outpos += 4;
		}
	}
	return outpos;
}

unsigned char decodeBase64Map(unsigned char a)
{
	if(a >= 'A' && a <= 'Z')
		return a - 'A';
	if(a >= 'a' && a <= 'z')
		return 26 + a - 'a';
	if(a >= '0' && a <= '9')
		return 52 + a - '0';
	if(a == '+')
		return 62;
	if(a == '/')
		return 63;
	if(a == '=')
		return 0;
	return -1;
}

void _decodeBase64(unsigned char *in, unsigned char *out)
{
	unsigned char map[4];
	map[0] = decodeBase64Map(in[0]);
	map[1] = decodeBase64Map(in[1]);
	map[2] = decodeBase64Map(in[2]);
	map[3] = decodeBase64Map(in[3]);
	out[0] = ((map[0] << 2) & 0xFC) | ((map[1] >> 4) & 0x03);
	out[1] = ((map[1] << 4) & 0xF0) | ((map[2] >> 2) & 0x0F);
	out[2] = ((map[2] << 6) & 0xC0) | ((map[3] >> 0) & 0x3F);
}

int decodeBase64(unsigned char *inbuf, int insize, unsigned char *outbuf, int outsize)
{
	int inpos = 0, outpos = 0;
	if(insize % 4)
		return -1;

	while(inpos != insize) {
		if(outpos + 3 > outsize)
			return -1;
		_decodeBase64(inbuf + inpos, outbuf + outpos);
		if(*(inbuf + inpos + 2) == '=') {
			outpos += 1;
			break;
		} else
			if(*(inbuf + inpos + 3) == '=') {
				outpos += 2;
				break;
			} else
				outpos += 3;
		inpos += 4;
	}
	return outpos;
}

/***************************************************************/
/********************执行命令，结果存入buf中**********************/
/***************************************************************/
void executeCMD(char *cmd, char *result)
{
	char buf_ps[1024];
	char ps[1024]={0};
	FILE *ptr;
	strcpy(ps, cmd);
	if((ptr=popen(ps, "r"))!=NULL)
	{   
		while(fgets(buf_ps, 1024, ptr)!=NULL)
		{   
			strcat(result, buf_ps);
			if(strlen(result)>1024) break;
		}   
		pclose(ptr);
		ptr = NULL;
	}   
	else
		print_data("popen %s error\n", ps);
}

#if 0
/***************************************************************/
/*******************获取wget_log内容，查找100%的次数***********************/
/***************************************************************/
int substring(char *str,char *str1)
{
	int x=0;
	char *p;//任意附个初始值
	do{
		p=strstr(str,str1);//1.p指针指向strstr的返回值。3.再一次循环到 这里函数的参数发生变化，p重新指向strstr返回值，如此循环。
		if(p != NULL) {
			str=p+1;//2.str同样指向strstr返回值p的下一个地址。
			x=x+1;
		}
	}while(p!=NULL);
	return x;
}

int file_fflush(char *filename)
{
	FILE *fp;
	int j = 0;
	size_t i;
	char contentbuf[8196];


	fp = fopen(filename, "rb");
	if (fp == NULL) {
		print_data("error\n");
		return -1;
	} else {
		while (1) {
			i = fread(&contentbuf[j], 1, 1, fp);
			if (i == 0)
				break;
		}
	}

	fflush(fp);
	fclose(fp);

	//	int   nRet=   0,   nStart   =   0;
	//	CString   str = contentbuf;
	//	CString   sub = "100%"
	//	while(-1!=(nStart=str.Find(sub, nStart))
	//	{
	//		nStart+=sub.GetLength();
	//		++nRet;
	//	}
	//	return   nRet;

	char substr[]= "100%";
	return substring(contentbuf, substr);
}
#endif

/***************************************************************/
/********************广告文件下载**********************/
/***************************************************************/
void download_advert(char *name, int *type, int *num, char *url)
{
	int i;
	char cmdbuf[256];
	char cmdbuf1[256];
	//char RESULT[256];

	print_data("name=%s, type=%d, num=%d, url=%s\n",name, *type, *num,url);
	/*****************建立本地广告路径*******************/
	sprintf(cmdbuf, "cd %s && mkdir -p %s && cd %s && touch download", ADVERT_HOME, name, name);
	print_data("%s\n", cmdbuf);
	system(cmdbuf);

	/*****************写download文件的内容*******************/
	//	if(*num == 1)
	//	{
	//		switch(*type)
	//		{
	//			case 1:
	//				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s.txt >> download", ADVERT_HOME, name, url, name);
	//				system(cmdbuf1);
	//				break;
	//			case 2:
	//				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s.jpg >> download", ADVERT_HOME, name, url, name);
	//				system(cmdbuf1);
	//				break;
	//			case 3:
	//				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s.mp4 >> download", ADVERT_HOME, name, url, name);
	//				system(cmdbuf1);
	//				break;
	//		}
	//
	//	}
	//	else if(*num > 1)
	//	{
	for(i=0;i<*num;i++)
	{
		switch(*type)
		{
			case 1:
				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s%d.txt >> download", ADVERT_HOME, name, url, name, i);
				system(cmdbuf1);
				break;
			case 2:
				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s%d.jpg >> download", ADVERT_HOME, name, url, name, i);
				system(cmdbuf1);
				break;
			case 3:
				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s%d.mp4 >> download", ADVERT_HOME, name, url, name, i);
				system(cmdbuf1);
				break;
			case 4:

				sprintf(cmdbuf1, "cd %s/%s && echo %s/%s%d.mp3 >> download", ADVERT_HOME, name, url, name, i);
				//	printf("写进download的命令=%s\n",cmdbuf1);
				system(cmdbuf1);
				break;
			case 5:
				if(i==0)
					sprintf(cmdbuf1, "cd %s/%s && echo %s/music/%s%d.mp3 >> download", ADVERT_HOME, name, url, name, i);
				else
					sprintf(cmdbuf1, "cd %s/%s && echo %s/pic/%s%d.jpg >> download", ADVERT_HOME, name, url, name, i-1);
				system(cmdbuf1);
				break;
			case 6:
				break;
			default:
				break;
		}
	}
	if (*type==6)
	{
		/*************将所有的文件下载到name的文件夹下***********************/
		sprintf(cmdbuf1,"cd %s/%s && mkdir -p %s",ADVERT_HOME,name,name);
		system(cmdbuf1);
		sprintf(cmdbuf1, "cd %s/%s/%s && wget -q -r -nd -nc -np -l1 -A *.txt -A *.jpg -A *.mp3 %s && cd ../ && touch downloadadvert.ok ", ADVERT_HOME,name, name,url);

	}
	else
	{	
		sprintf(cmdbuf1, "cd %s/%s && wget --restrict-file-names=nocontrol -cbi download &&  touch downloadadvert.ok", ADVERT_HOME, name);
		//printf("加载donload文件夹的命令=%s\n",cmdbuf);
	}
	print_data("%s\n", cmdbuf1);
	system(cmdbuf1);

	/*****************1s钟一次检查文件是否下载晚****************/
	/***************2017 12 04 ping_modify*********************/
	/****************check_download is ok ?********************/

	char filebuf[256];  
	filebuf[0] = '\0';
	int download_times=0;
	sprintf(filebuf, "%s/%s/downloadadvert.ok", ADVERT_HOME, name);
	while(1)
	{
		download_times++;
		sleep(10);
		if (!access(filebuf, 0))
			break;
		if(download_times>18)
			break;			
	}
#if 0/*****ping_modify******/
	if(*type == 1)
		for(i=0;i<*num;i++) 
			sleep(3);
	else if(*type == 2)
		for(i=0;i<*num;i++) 
			sleep(5);
	else if(*type == 3)
		for(i=0;i<*num;i++) 
			sleep(15);
	else if(*type == 4)
		for(i=0;i<*num;i++) 
			sleep(15);
	else if(*type == 5)
		for(i=0;i<*num;i++) 
			sleep(5);
	else if(*type==6)
		for(i=0;i<*num;i++)
			sleep(5);
	if(*type==5)
	{
		/***********将下载的单个文件移动到music 和pic 的文件夹下面********************/
		sprintf(cmdbuf1, "cd %s/%s &&  mkdir -p music pic", ADVERT_HOME, name);
		system(cmdbuf1);
		sprintf(cmdbuf1, "cd %s/%s && mv *.mp3 music/ && mv *.jpg pic/", ADVERT_HOME, name);
		system(cmdbuf1);
	}
#endif
	//		if(file_fflush(fileWgetLog) >= *num) break;
	/*		RESULT[0]='\0';
			executeCMD(cmdbuf, RESULT);
			print_data("RESULT=%s, number=%d\n", RESULT, *num);
			if(atoi(RESULT) >= *num) break;
	 */
	//	}
}


/***************************************************************/
/********************将文件base64编码，然后分成小文件**********************/
/***************************************************************/
int MAXLENTXT = 1024*1024*2;
int MAXLENJPG = 1024*1024*5*10;
int MAXLENAVI = 1024*1024*5*20;
int MAXLENWAV = 1024*1024*5*20;
int MAXLENMAX = 1024*1024*5*20;
int MAXLENGEN = 1024*1024*10*20;
int file_base64_split(char *path, char *filename, int *type, int *partnum)
{
	int k,j,FILESIZE,MAXLENTAR=0;
	int result=0;
	char FILENAME[256]; 
	//char cmdbuf[256]; 

	sprintf(FILENAME,"%s/%s.tar.gz", path, filename);
	print_data("file name = %s\n", FILENAME);
	FILE *fileTAR = fopen(FILENAME, "rb"); //打开文件
	if( fileTAR == NULL )	{	print_data("%s not exit\n", FILENAME);	return -1;	} 
	fseek(fileTAR, 0L, SEEK_END);  
	FILESIZE = ftell(fileTAR);  
	fseek(fileTAR, 0L, SEEK_SET);
	unsigned char *readbuftar = new unsigned char[FILESIZE+1];
	unsigned char *readbuftarout = NULL; 
	switch(*type)
	{
		case 1:
			readbuftarout = new unsigned char[MAXLENTXT];
			MAXLENTAR = MAXLENTXT;
			break;
		case 2:
			readbuftarout = new unsigned char[MAXLENJPG];
			MAXLENTAR = MAXLENJPG;
			break;
		case 3:
			readbuftarout = new unsigned char[MAXLENAVI];
			MAXLENTAR = MAXLENAVI;
			break;
		case 4:
			readbuftarout = new unsigned char[MAXLENWAV];
			MAXLENTAR = MAXLENWAV;
			break;
		case 5:
			readbuftarout = new unsigned char[MAXLENWAV];
			MAXLENTAR = MAXLENMAX;
			break;
		case 6:
			readbuftarout = new unsigned char[MAXLENGEN];
			MAXLENTAR = MAXLENGEN;
			break;

		default:
			break;
	}

	if( (int)(fread(readbuftar, sizeof(unsigned char), FILESIZE, fileTAR)) != FILESIZE )
	{
		print_data("%s file read is error!", FILENAME);
		return -1;
	}
	readbuftar[FILESIZE] = '\0';
	fclose(fileTAR);
	/**************************序列化base64编码***********************************/
	int LENGTH1OUT = encodeBase64(readbuftar, FILESIZE, readbuftarout, MAXLENTAR);
	readbuftarout[LENGTH1OUT] = '\0';
	//mysqlAdvert[*index].len = LENGTH1OUT;
	print_data("LENGTH1OUT = %d \n", LENGTH1OUT);
	if(LENGTH1OUT <= 1024*1024)
	{
		*partnum =1;
		//mysqlAdvert[*index].partnumber = 1;
		//print_data("index=%d, partnumber=%d\n", *index, 1);
		/**************************创建part0文件***********************************/
		char FILENAME_PART_TAR0[128];
		sprintf(FILENAME_PART_TAR0,"%s/%s.part0", path, filename);
		FILE *filePartTar0 = fopen(FILENAME_PART_TAR0, "w+");
		if( filePartTar0 == NULL )	{	print_data("write open part file --%s-- fail !\n", FILENAME_PART_TAR0);	return -1;	}
		for(k=0;k<LENGTH1OUT;k++)
			fputc(readbuftarout[k], filePartTar0);
		fclose(filePartTar0);
		result = LENGTH1OUT;
	}
	else
	{
		/**************************以下代码是拆分文件***********************************/
		int partNumberTar = LENGTH1OUT/(1024*1024);
		*partnum = partNumberTar;
		//mysqlAdvert[*index].partnumber = partNumberTar;
		//print_data("index=%d, partnumber=%d\n", *index, partNumberTar);
		int partRemainTar = LENGTH1OUT%(1024*1024);
		char FILENAME_PART_TARn[128];
		/***************************************************************************/
		/**************************创建partNumberTar对应的文件多个1M文件***********************************/
		/***************************************************************************/
		FILE *filePartTarN; 
		for(j=0;j<partNumberTar;j++)
		{
			sprintf(FILENAME_PART_TARn,"%s/%s.part%d", path, filename, j);
			filePartTarN = fopen(FILENAME_PART_TARn, "w+");
			if( filePartTarN == NULL )	{	print_data("write open part file --%s-- fail !\n", FILENAME_PART_TARn);	return -1;	}
			int tmpvaluetar = j*1024*1024; 
			for(k=0;k<1024*1024;k++)
				fputc(readbuftarout[k+tmpvaluetar], filePartTarN);
			fclose(filePartTarN);
		}
		/***************************************************************************/
		/**************************创建partRemainTar对应的文件***********************************/
		/***************************************************************************/
		sprintf(FILENAME_PART_TARn,"%s/%s.part%d", path, filename, partNumberTar);
		FILE *filePartTarRemain = fopen(FILENAME_PART_TARn, "w+");
		if( filePartTarRemain == NULL )	{	print_data("write open part file --%s-- fail !\n", FILENAME_PART_TARn);	return -1;	}
		int tmpvaluetar1 = partNumberTar*1024*1024; 
		for(k=0;k<partRemainTar;k++)
			fputc(readbuftarout[k+tmpvaluetar1], filePartTarRemain);
		fclose(filePartTarRemain);
		result = LENGTH1OUT;
	}

	delete readbuftar;
	delete readbuftarout;
	return result;
}


/***************************************************************/
/********************operator广告文件：下载、压缩、分割**********************/
/***************************************************************/


int operator_advert_file()
{
	int i,TYPE,NUMBER,general_num;
	char *NAME;
	char *URL;
	char FILEDIR[128];
	char FILENAME_SPLITDONE[128];
	char cmdbuf[256];

	for(i=0;i<(int)mysqlAdvert.size();i++)
	{

		print_data("(mysqlAdvert.at(i).id=%d\n",mysqlAdvert.at(i).id);
		if(mysqlAdvert.at(i).id == 0) break;
		NAME = mysqlAdvert.at(i).name;
		TYPE = mysqlAdvert.at(i).type;
		NUMBER = mysqlAdvert.at(i).number;
		URL = mysqlAdvert.at(i).url;

		/****************判断是否已经处理过******************/
		sprintf(FILEDIR, "%s/%s", ADVERT_HOME, NAME);
		sprintf(FILENAME_SPLITDONE, "%s/%s", FILEDIR, "split.done");
		if(!access(FILENAME_SPLITDONE, 0)) continue; //继续下一个

		/****************下载新广告到FILEDIR目录******************/
		download_advert(NAME, &TYPE, &NUMBER, URL);
		/****************压缩文件成tar.gz******************/
		char filebuf[256];
		filebuf[0] = '\0';
		switch(TYPE)
		{
			case 1:
				sprintf(filebuf, "%s/%s%d.txt", FILEDIR, NAME, NUMBER-1);
				break;
			case 2:
				sprintf(filebuf, "%s/%s%d.jpg", FILEDIR, NAME, NUMBER-1);
				break;
			case 3:
				sprintf(filebuf, "%s/%s%d.mp4", FILEDIR, NAME, NUMBER-1);
				break;
			case 4:
				sprintf(filebuf, "%s/%s%d.mp3", FILEDIR, NAME, NUMBER-1);
				break;	
			case 5:
				sprintf(filebuf, "%s/pic/%s%d.jpg", FILEDIR, NAME, NUMBER-2);
				break;	
			case 6:

				break;
			default:
				break;
		}
		/**********ping_modify***********/
		if(TYPE!=6)
		{
			if(!access(filebuf, 0))
				print_data("%s is EXISIT !\n", filebuf);
			else
				continue;
			if(TYPE==5)
				sprintf(cmdbuf, "cd %s && tar zcvf %s.tar.gz pic/*.jpg music/*.mp3", FILEDIR, NAME); 
			else
				sprintf(cmdbuf, "cd %s && tar zcvf %s.tar.gz %s*", FILEDIR, NAME, NAME);
		}
		else
		{
			/*********获取文件夹下面的文件数量*******/
			/*******检查是否将文件全部下载完*********/
			general_num=get_general_filenum(NAME);
			if(!general_num<NUMBER)	
				print_data("%s is EXISIT !\n", filebuf);
			else
				continue;
			sprintf(cmdbuf, "cd %s/%s && tar zcvf %s.tar.gz * &&  mv  %s.tar.gz ../ ", FILEDIR, NAME, NAME,NAME);
			//printf("yasuobuf=%s\n",cmdbuf);
			system(cmdbuf);
		}
#if 0
		if(TYPE!=6)
		{	
			int while_number = 0;
			while(while_number < 3)
			{

				if ( !access(filebuf, 0) )
				{
					print_data("%s is EXISIT !\n", filebuf);
					sleep(3);
					break;
				}
				else
				{
					while_number++;
					print_data("%s DOESN'T EXISIT!\n", filebuf);
					sleep(5);
				}
			}

			if(TYPE==5)
				sprintf(cmdbuf, "cd %s && tar zcvf %s.tar.gz pic/*.jpg music/*.mp3", FILEDIR, NAME);		
			else
				sprintf(cmdbuf, "cd %s && tar zcvf %s.tar.gz %s*", FILEDIR, NAME, NAME);

		}else{
			int while_general_number=0;
			while(while_general_number<3){
				general_num=get_general_filenum(NAME);
				if(!general_num<NUMBER)
				{
					sleep(3);
					break;
				}
				else
				{
					while_general_number++;
					sleep(5);
				}
			}

			sprintf(cmdbuf, "cd %s && tar zcvf %s.tar.gz %s/", FILEDIR, NAME, NAME);
		}	
#endif
		system(cmdbuf);
		char tarbuff[256];
		tarbuff[0]='\0';
		sprintf(tarbuff, "%s/%s.tar.gz", FILEDIR, NAME);
		sleep(2);
		if(access(tarbuff, 0))
				continue;
		int PARTNUMBER = 0;
		int LENGTH = file_base64_split(FILEDIR, NAME, &TYPE, &PARTNUMBER);
		if((LENGTH > 0) && (PARTNUMBER > 0))
		{
			/**************************创建split.done文件***********************************/
			sprintf(cmdbuf, "echo %d > %s", PARTNUMBER, FILENAME_SPLITDONE);
			system(cmdbuf);
			sprintf(cmdbuf, "echo %d >> %s", LENGTH, FILENAME_SPLITDONE);
			system(cmdbuf);
		}
	}

	return 0;
}



void * process_handleBase64(void *parg)
{
	while(1)
	{   
		sleep(20);
		operator_advert_file();
	}   

	return NULL;
}

/**********获取文件夹的文件个数*****************/

int get_general_filenum(char* name)
{
	int num=0;
	char cmdbuf[256];
	char filetext[32];
	char filedir[256];
	sprintf(cmdbuf,"cd %s/%s/%s && ls | wc -l > filenum ",ADVERT_HOME,name,name);
	print_data("cmdbuf=%s\n",cmdbuf);
	system(cmdbuf);
	sprintf(filedir,"%s/%s/%s/filenum",ADVERT_HOME,name,name);
	print_data("cmdbuf=%s\n",cmdbuf);
	FILE *pf = fopen(filedir, "r");
	if(pf == NULL) {
		return 0;
	}   
	memset(filetext, 0, sizeof(filetext));  
	/*********读取第一行字符串*********************/
	fgets(filetext, sizeof(filetext) - 1, pf);   
	fclose(pf); 
	num=atoi(filetext);
	filedir[0]='\0';
	filetext[0]='\0';
	cmdbuf[0]='\0';
	return num-1;
}



