#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "global.h"
#include <time.h>
#include <vector>


using namespace std;
//odbc
/* 检测返回代码是否为成功标志，当为成功标志返回TRUE，否则返回FALSE */
#define RC_SUCCESSFUL(rc)  ((rc) == SQL_SUCCESS || (rc) == SQL_SUCCESS_WITH_INFO)
/* 检测返回代码是否为失败标志，当为失败标志返回TRUE，否则返回FALSE */
#define RC_NOTSUCCESSFUL(rc) (!(RC_SUCCESSFUL(rc)))


#define ROW_ARRAY_SIZE 1000

SQLHENV      henv;  /* 环境句柄 */
SQLHDBC      hdbc;  /* 连接句柄 */
SQLHSTMT     hsmt;  /* 语句句柄 */
SQLHSTMT     sqlhsmt;  /* 语句句柄 */
SQLHSTMT     hsmtread;  /* 语句句柄 */
SQLHSTMT     hsmtupdate;  /* 语句句柄 */
//SQLHSTMT     hsmtaddusr;  /* 语句句柄 */
//SQLHSTMT     hsmtdelusr;  /* 语句句柄 */
//SQLHSTMT     hsmtupdate;  /* 语句句柄 */


static int odbc_reconnect_flag=0;
//char mysql_id[256];
//struct mysql_advert mysqlAdvert[100];
vector<mysql_advert> mysqlAdvert;

bool checkIp(char *str)//a rough check
{
	int dot_count = 0;
	int num_count = 0;
	int num_val = 0;
	while((*str))
	{
		if((*str) != '.')
		{
			if((*str) <= '9' && (*str) >= '0')
			{
				++ num_count;
				num_val = num_val * 10 + (*str) - '0';
			}
			else
				return false;
		}
		else
		{
			++ dot_count;
			if(num_count < 1 || num_count > 4 || num_val < 0 || num_val >255)
				//check if the current segment is 1~3 numbers
				return false;
			num_count = 0;
			num_val = 0;
		}
		++ str;
	}
	if(dot_count != 3)
		return false;
	return true;
}

int get_dmserver_dsn_usrname_passwd(char *resdsn, char *resname, char *respasswd)
{
	FILE *fp;
	char tmpValue[32];
	char tmpbuf[256];
	int tlen, len;
	char *pos1, *pos2;

	fp=fopen("/etc/advertServer.conf", "r");	
//	fp=fopen("./advertServer.conf", "r");
	if (fp != NULL)
	{
		while ((fgets(tmpbuf, 255, fp)) != NULL)
		{
			tlen = strlen(tmpbuf);
			if(tmpbuf[tlen - 1] == '\n')  tmpbuf[tlen - 1]='\0';

			if((pos1=strstr(tmpbuf, "[")) != NULL)
			{
				pos1 += 1;
				pos2 = strstr(pos1, "]");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resdsn, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "username=")) != NULL)
			{
				pos1 += 9; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resname, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "passwd=")) != NULL)
			{
				pos1 += 7; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(respasswd, tmpValue);
				break;
			}
		}

		fclose(fp);
		fp=NULL;
	}
	else
		print_data("open /etc/advertServer.conf failed \n");

	return 0;
}


void initOdbc(void)
{
	char dsn[32];
	//char ip[16];
	//char port[32];
	char usrname[32];
	char passwd[32];

	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);
	print_data("dsn=%s, usrname=%s, passwd=%s\n", dsn, usrname, passwd);

	/* 申请一个环境句柄  */
	SQLAllocHandle(SQL_HANDLE_ENV, NULL, &henv);
	/* 设置环境句柄的ODBC版本  */
	SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER);
	/* 申请一个连接句柄  */
	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	//SQLConnect(hdbc, (SQLCHAR *)"DMSERVER", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS);
	//SQLConnect(hdbc, (SQLCHAR *)"DMSERVER", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS, (SQLCHAR *)"SYSDBA", SQL_NTS);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	/* 申请一个语句句柄  */
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &sqlhsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtupdate);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtaddusr);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtdelusr);
	//	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtupdate);
}

void initJubing()
{
	char dsn[32];
	char usrname[32];
	char passwd[32];
	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);

	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &sqlhsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtread);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtupdate);

}


void endOdbc(void)
{
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, sqlhsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtupdate);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtaddusr);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtdelusr);
	//	SQLFreeHandle(SQL_HANDLE_STMT, hsmtupdate);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	/* 释放环境句柄  */
	SQLFreeHandle(SQL_HANDLE_ENV, henv);
}

void endJubing(){
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, sqlhsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtread);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtupdate);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
}
void get_advert_endflag_true()
{
	unsigned int i;
	char cmdbuf[256];
	struct	mysql_advert mysql_ad;
	struct advert_info {
		SQLINTEGER id;
		SQLLEN idInd;
		SQLCHAR position[32];
		SQLLEN positionInd;
		SQLCHAR pid[32];
		SQLLEN pidInd;
		SQLCHAR name[32];
		SQLLEN nameInd;
		SQLINTEGER type;
		SQLLEN typeInd;
		SQLINTEGER number;
		SQLLEN numberInd;
		SQLCHAR url[128];
		SQLLEN urlInd;
		SQLCHAR date[32];
		SQLLEN dateInd;
		SQLCHAR time[32];
		SQLLEN timeInd;
	};
	/***********清空mysqlAdvert的数据*********************/
	mysqlAdvert.clear();
	/***********清空mysqlAdvert的内存**********************/
	 vector<mysql_advert>(mysqlAdvert).swap(mysqlAdvert);
# if 0
	for(i=0;i<100;i++)
	{
		mysqlAdvert[i].id = 0;
		mysqlAdvert[i].position[0] = '\0';
		mysqlAdvert[i].name[0] = '\0';
		mysqlAdvert[i].type = 0;
		mysqlAdvert[i].number = 0;
		mysqlAdvert[i].partnumber = 0;
		mysqlAdvert[i].url[0] = '\0';
		mysqlAdvert[i].len = 0;
		mysqlAdvert[i].date[0] = '\0';
		mysqlAdvert[i].time[0] = '\0';i
			mysqlAdvert[i].pid[0] = '\0';
	}
#endif
	/**************************************************************/
	/*******************获取send_flag****************************/
	/**************************************************************/
	struct advert_info OrderInfoArray[ROW_ARRAY_SIZE];
	SQLUINTEGER NumRowsFetched;
	SQLUSMALLINT RowStatusArray[ROW_ARRAY_SIZE]; 
	SQLRETURN rc;

	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_BIND_TYPE,(SQLPOINTER *)sizeof(advert_info),0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_ARRAY_SIZE,(SQLPOINTER *)ROW_ARRAY_SIZE,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_STATUS_PTR,RowStatusArray,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROWS_FETCHED_PTR,&NumRowsFetched,0);

	sprintf( cmdbuf, "SELECT id,position, push_pid,name,type,number,url,date,time FROM advert_resource WHERE send_flag='1';");
	print_data("%s\n", cmdbuf);

	SQLPrepare(hsmt,(SQLCHAR *)cmdbuf, SQL_NTS);

	SQLBindCol(hsmt,1,SQL_C_ULONG,&OrderInfoArray[0].id,sizeof(OrderInfoArray[0].id),&OrderInfoArray[0].idInd);
	SQLBindCol(hsmt,2,SQL_C_CHAR,&OrderInfoArray[0].position,sizeof(OrderInfoArray[0].position),&OrderInfoArray[0].positionInd);
	SQLBindCol(hsmt,3,SQL_C_CHAR,&OrderInfoArray[0].pid,sizeof(OrderInfoArray[0].pid),&OrderInfoArray[0].pidInd);
	SQLBindCol(hsmt,4,SQL_C_CHAR,&OrderInfoArray[0].name,sizeof(OrderInfoArray[0].name),&OrderInfoArray[0].nameInd);
	SQLBindCol(hsmt,5,SQL_C_ULONG,&OrderInfoArray[0].type,sizeof(OrderInfoArray[0].type),&OrderInfoArray[0].typeInd);
	SQLBindCol(hsmt,6,SQL_C_ULONG,&OrderInfoArray[0].number,sizeof(OrderInfoArray[0].number),&OrderInfoArray[0].numberInd);
	SQLBindCol(hsmt,7,SQL_C_CHAR,&OrderInfoArray[0].url,sizeof(OrderInfoArray[0].url),&OrderInfoArray[0].urlInd);
	SQLBindCol(hsmt,8,SQL_C_CHAR,&OrderInfoArray[0].date,sizeof(OrderInfoArray[0].date),&OrderInfoArray[0].dateInd);
	SQLBindCol(hsmt,9,SQL_C_CHAR,&OrderInfoArray[0].time,sizeof(OrderInfoArray[0].time),&OrderInfoArray[0].timeInd);
	rc=SQLExecute(hsmt);
	if(rc == SQL_INVALID_HANDLE)
	{   
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return ;
	}   

	while (( rc = SQLFetchScroll(hsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	{   
		for (i = 0 ;i< NumRowsFetched; i++ ) 
		{   
			if (RowStatusArray[ i ] == SQL_ROW_SUCCESS||RowStatusArray[i] == SQL_ROW_SUCCESS_WITH_INFO ) 
			{   

				mysql_ad.id = 0;
				mysql_ad.position[0] = '\0';
				mysql_ad.name[0] = '\0';
				mysql_ad.type = 0;
				mysql_ad.number = 0;
				mysql_ad.partnumber = 0;
				mysql_ad.url[0] = '\0';
				mysql_ad.len = 0;
				mysql_ad.date[0] = '\0';
				mysql_ad.time[0] = '\0';
				mysql_ad.pid[0] = '\0';

				if (OrderInfoArray[i].idInd == SQL_NULL_DATA)//1
					print_data("id=NULL\t");
				else
					print_data("%d\t ", (int)OrderInfoArray[i].id);    

				if (OrderInfoArray[i].positionInd == SQL_NULL_DATA)//2
					print_data("position=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].position); 

				if (OrderInfoArray[i].pidInd == SQL_NULL_DATA)//3
				{
					print_data("pid=NULL\t");
					mysql_ad.pid[0]='\0';
				}
				else
				{
					print_data("%s\t " ,  OrderInfoArray[i].pid);    
					mysql_ad.pid[0]= '\0';
					strcpy(mysql_ad.pid, (char *)OrderInfoArray[i].pid);
				}

				if (OrderInfoArray[i].nameInd == SQL_NULL_DATA)//4
					print_data("name=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].name);    

				if (OrderInfoArray[i].typeInd == SQL_NULL_DATA)//5
					print_data("type=NULL\t");
				else
					print_data("%d\t " , (int)OrderInfoArray[i].type);    

				if (OrderInfoArray[i].numberInd == SQL_NULL_DATA)//6
					print_data("number=NULL\t");
				else
					print_data("%d\t " , (int)OrderInfoArray[i].number);    

				if (OrderInfoArray[i].urlInd == SQL_NULL_DATA)//7
					print_data("url=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].url);    

				if (OrderInfoArray[i].dateInd == SQL_NULL_DATA)//8
					print_data("date=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].date);    

				if (OrderInfoArray[i].timeInd == SQL_NULL_DATA)//9
					print_data("time=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].time);


				print_data("\n\n");

				mysql_ad.id = (int)OrderInfoArray[i].id;
				strcpy(mysql_ad.position, (char *)OrderInfoArray[i].position);
				strcpy(mysql_ad.name, (char *)OrderInfoArray[i].name);
				mysql_ad.type = (int)OrderInfoArray[i].type;
				mysql_ad.number = (int)OrderInfoArray[i].number;
				strcpy(mysql_ad.url, (char *)OrderInfoArray[i].url);
				strcpy(mysql_ad.date, (char *)OrderInfoArray[i].date);
				strcpy(mysql_ad.time, (char *)OrderInfoArray[i].time);

				print_data("odbc中 OrderInfoArray[i].pid =%s\n", (char *)OrderInfoArray[i].pid);
				print_data("odbc中 mysqlAdvert.pid =%s\n", mysql_ad.pid);
				print_data("odbc中 mysqlAdvert.name =%s\n", mysql_ad.name);

			}
			mysqlAdvert.push_back(mysql_ad);
		}   
	}   

	SQLCloseCursor(hsmt);
}


/**************得到时间戳的方法****************************/
long gettick(int iY,int iM,int iD,int iH,int iMin,int iS)	
{    struct tm stm;

	memset(&stm,0,sizeof(stm));

	stm.tm_year=iY-1900;
	stm.tm_mon=iM-1;
	stm.tm_mday=iD;
	stm.tm_hour=iH;
	stm.tm_min=iMin;
	stm.tm_sec=iS;

	return mktime(&stm);
}

/**********得到当前时间的时间戳********************/
int  getcurrenttime()
{
	std::string s;
	char stime[256] = { 0 };
	time_t now_time;
	time(&now_time);
	strftime(stime, sizeof(stime), "%F %H:%M:%S", localtime(&now_time));
	s = stime;
	struct tm tm;
	strptime(s.c_str(),"%F %H:%M:%S", &tm) ;
	time_t ft=mktime(&tm);
	int i_time = ft;
	return i_time;
}




int get_time_stamp(char *date ,char *time)
{
	char getdate [32];
	char gettime [32];	

	/*********初始化年份很日期*******************/
	getdate[0] = '\0';
	memcpy(getdate, date, 32);
	gettime[0] = '\0';
	memcpy(gettime,time,32);
	string strdate;
	string strtime;
	strdate=getdate;
	strtime=gettime;
#if 1
	/*********获取广告最小时间戳***************/
	string minyear(strdate.substr(0,4));	
	string minmon(strdate.substr(4,2));	
	string mindate(strdate.substr(6,2));
	string minhour(strtime.substr(0,2));
	string minsecond(strtime.substr(3,2));
#endif
	/**********获取最大时间戳********************/
	string maxyear(strdate.substr(9,4));	
	string maxmon(strdate.substr(13,2));	
	string maxdate(strdate.substr(15,2));
	string maxhour(strtime.substr(6,2));
	string maxsecond(strtime.substr(9,2));
#if 0
	print_data("\nstryear=%s\n",minyear.c_str()); 
	print_data("strmon=%s\n",minmon.c_str()); 
	print_data("strdate=%s\n",mindate.c_str()); 
	print_data("strhour=%s\n",minhour.c_str()); 
	print_data("strsecond=%s\n",minsecond.c_str()); 

	print_data("\nmaxyear=%s\n",maxyear.c_str()); 
	print_data("maxmon=%s\n",maxmon.c_str()); 
	print_data("maxdate=%s\n",maxdate.c_str()); 
	print_data("maxhour=%s\n",maxhour.c_str()); 
	print_data("maxsecond=%s\n",maxsecond.c_str()); 
#endif	
	/*********最小时间戳********************/
	int mintmap = 0;
	mintmap = gettick(atoi(minyear.c_str()),	atoi(minmon.c_str()), atoi(mindate.c_str()), 
			atoi(minhour.c_str()), atoi(minsecond.c_str()), 0);
	print_data("minshijiancuo=%d\n",mintmap);
	/***********最大的时间戳***************/
	int maxtmap = 0;
	maxtmap = gettick(atoi(maxyear.c_str()),	atoi(maxmon.c_str()), atoi(maxdate.c_str()), 
			atoi(maxhour.c_str()), atoi(maxsecond.c_str()), 0);
	print_data("maxshijiancuo=%d\n",maxtmap);
	/************获取当前的时间戳**********/
	int cutmap =0;
	cutmap = getcurrenttime() - 5 * 60;
	print_data("currenttime=%d\n",cutmap);
	/*
	//还未推送
	{	
	return 0 ;
	}
	//正在推送
	if ((cutmap>mintmap) && (cutmap<maxtmap))
	{
	return 1;

	}
	//已经推送
	 */
	if (cutmap>maxtmap)
	{
		return -1;
	}else
	{
		return 0;
	}

}

/****************更新数据库endflag******************/
void update_mysql_sendflag(int id,int flag)
{
	char cmdbuf[256] ;
	SQLRETURN rc;

	sprintf( cmdbuf, "UPDATE advert_resource SET send_flag='%d' WHERE id='%d';", flag,id);
	print_data("%s\n", cmdbuf);

	rc = SQLExecDirect( hsmtupdate, (SQLCHAR *)cmdbuf, SQL_NTS);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		print_data("SQLExecDirect odbc_reconnect_flag!\n");
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		//cout << "SQLExecDirect error!" << endl ;
		print_data("SQLExecDirect error!\n");
		return;
	}
	print_data( " 修改MySQL成功\n");
	SQLCloseCursor(hsmtupdate);

}

/********************************************/
/*************查询并修改数据库状态****************/
/******************************************/
void query_mysql_endflag(void)
{

	unsigned int i;
	char cmdbuf[256];
	struct advert_info {
		SQLINTEGER id;
		SQLLEN idInd;
		SQLCHAR date[32];
		SQLLEN dateInd;
		SQLCHAR time[32];
		SQLLEN timeInd;
		SQLINTEGER send;
		SQLLEN sendInd;

	};
	struct advert_info OrderInfoArray[ROW_ARRAY_SIZE];
	SQLUINTEGER NumRowsFetched;
	SQLUSMALLINT RowStatusArray[ROW_ARRAY_SIZE];
	SQLRETURN rc;

	SQLSetStmtAttr(sqlhsmt,SQL_ATTR_ROW_BIND_TYPE,(SQLPOINTER *)sizeof(advert_info),0);
	SQLSetStmtAttr(sqlhsmt,SQL_ATTR_ROW_ARRAY_SIZE,(SQLPOINTER *)ROW_ARRAY_SIZE,0);
	SQLSetStmtAttr(sqlhsmt,SQL_ATTR_ROW_STATUS_PTR,RowStatusArray,0);
	SQLSetStmtAttr(sqlhsmt,SQL_ATTR_ROWS_FETCHED_PTR,&NumRowsFetched,0);

	sprintf( cmdbuf, "SELECT id,time,date,send_flag FROM advert_resource where send_flag='1';");

	print_data("%s\n", cmdbuf);
	print_data("%s\n", cmdbuf);

	SQLPrepare(sqlhsmt,(SQLCHAR *)cmdbuf, SQL_NTS);

	SQLBindCol(sqlhsmt,1,SQL_C_ULONG,&OrderInfoArray[0].id,sizeof(OrderInfoArray[0].id),&OrderInfoArray[0].idInd);
	SQLBindCol(sqlhsmt,2,SQL_C_CHAR,&OrderInfoArray[0].time,sizeof(OrderInfoArray[0].time),&OrderInfoArray[0].timeInd);
	SQLBindCol(sqlhsmt,3,SQL_C_CHAR,&OrderInfoArray[0].date,sizeof(OrderInfoArray[0].date),&OrderInfoArray[0].dateInd);
	SQLBindCol(sqlhsmt,4,SQL_C_ULONG,&OrderInfoArray[0].send,sizeof(OrderInfoArray[0].send),&OrderInfoArray[0].sendInd);

	rc=SQLExecute(sqlhsmt);
	if(rc == SQL_INVALID_HANDLE)
	{   
		odbc_reconnect_flag = 1;
		return ;
	}   
	while (( rc = SQLFetchScroll(sqlhsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	{   
		char sqldate [32];
		char sqltime [32];

		for (i = 0 ;i< NumRowsFetched; i++ ) 
		{   
			if (RowStatusArray[ i ] == SQL_ROW_SUCCESS||RowStatusArray[i] == SQL_ROW_SUCCESS_WITH_INFO ) 
			{   
				if (OrderInfoArray[i].idInd == SQL_NULL_DATA)//1
					print_data("id=NULL\t");
				else
					print_data("%d\t ", (int)OrderInfoArray[i].id);    

				if (OrderInfoArray[i].dateInd == SQL_NULL_DATA)//10
					print_data("date=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].time);    

				if (OrderInfoArray[i].timeInd == SQL_NULL_DATA)//11
					print_data("time=NULL\t");
				else
					print_data("%s\t " ,  OrderInfoArray[i].date);    
				if (OrderInfoArray[i].sendInd == SQL_NULL_DATA)//1
					print_data("id=NULL\t");
				else
					print_data("%d\t ", (int)OrderInfoArray[i].send);    
				strcpy(sqldate, (char *)OrderInfoArray[i].date);
				strcpy(sqltime, (char *)OrderInfoArray[i].time);
				/*********根据时间戳来判断是否修改数据库****************/
				int curtstatus = 0 ;
				curtstatus = get_time_stamp(sqldate ,sqltime);
				if(curtstatus==-1)
					/****************更新数据库状态**************************/
					update_mysql_sendflag((int)OrderInfoArray[i].id, curtstatus);	
			}
		}
	}	
	SQLCloseCursor(sqlhsmt);
}

void * process_handleOdbc(void *parg)
{
	while(1)
	{
		sleep(30);

		get_advert_endflag_true();
	}

	return NULL;
}

