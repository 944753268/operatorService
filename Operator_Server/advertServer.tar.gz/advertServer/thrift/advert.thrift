struct  Add{
	1: i32 id,
	2: string name,
	3: byte type,
	4: byte number,
	5: byte partnumber,
	6: i32 len,
	7: string content,
	8: byte endflag,
	9: string date,
	10: string time,
}

struct  Advert{
	1: optional Add add,
	2: required string mysql_id,
}

service AdvertService{
	Advert get(
			1:	string position,
			2:	string product_id,
			3:	string robot_id,
			4:	string advert_name,
			5:	byte advert_part,
			)
}

