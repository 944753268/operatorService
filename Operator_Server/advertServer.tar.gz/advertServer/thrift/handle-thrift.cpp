/*****************************************/
/****************jason_modify*************/
#include <string>  
#include <iostream>   
#include "AdvertService.h"    
#include <config.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>
#include <thrift/concurrency/ThreadManager.h>  
#include <thrift/concurrency/PosixThreadFactory.h>  
#include <thrift/server/TThreadPoolServer.h>  
#include <thrift/server/TThreadedServer.h>  
#include <thrift/server/TNonblockingServer.h>  
#include <server/TThreadPoolServer.h>
#include <server/TThreadedServer.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>    
#include <transport/TServerSocket.h>    
#include <transport/TBufferTransports.h>    
#include <concurrency/ThreadManager.h>    
#include <concurrency/PosixThreadFactory.h>    
#include <server/TThreadPoolServer.h>    
#include <server/TThreadedServer.h>    
#include "global.h"


#define  THREAD_POOL_SERVER 1	 

using namespace ::apache::thrift;    
using namespace ::apache::thrift::protocol;    
using namespace ::apache::thrift::transport;    
using namespace ::apache::thrift::server;    
using namespace ::apache::thrift::concurrency;    

using boost::shared_ptr;  
using namespace std;   



/*************************************************************************/
/********************************获取增加advert ID函数*****************************************/
/*************************************************************************/
static int exist_flag=0;

int get_advert_id(char* robotid, char* mysqlid)
{
	int i,j;
	int strbuf1[mysqlAdvert.size()];
	int strbuf2[mysqlAdvert.size()];

	i=0;
	char* token1 = strtok(robotid,"-");
	while(token1 != NULL){
		strbuf1[i++] = atoi(token1);
		token1 = strtok(NULL,"-");
	}
	print_data("i=%d\n",i);
	for(j=0;j<i;j++)
		print_data("%d ", strbuf1[j]);
	print_data("\n");
	int len =i;

	i=0;
	char* token2 = strtok(mysqlid,"-");
	while(token2 != NULL){
		strbuf2[i++] = atoi(token2);
		token2 = strtok(NULL,"-");
	}
	print_data("i=%d\n",i);
	for(j=0;j<i;j++)
		print_data("%d ", strbuf2[j]);
	print_data("\n");
	int len2 =i;

	for (i=0; i<len2; i++)
	{
		for (j=0; j<len; j++)
		{
			if (strbuf2[i] == strbuf1[j])
			{
				exist_flag = 1;
				break;
			}
		}
		if(exist_flag == 1)
		{
			exist_flag = 0;
			continue;
		}
		else
			break;
	}

	if(i == len2) return -1;
	return strbuf2[i];
}


/*************************************************************************/
/********************************将源文件分割成多个小文件*****************************************/
/*************************************************************************/
void FilePartition(FILE *sfp,FILE *dfp,int size)
{
	int s=size;
	char ch;
	while(s!=0)
	{
		ch=fgetc(sfp);
		if(ch==EOF)
			break;
		fputc(ch,dfp);
		s--;
	}
	fclose(dfp);
}


int get_advert_partnumber_length(char *dir, int *partnum, int *lenth)
{
	FILE *fp = NULL;
	char tmpbuf[255];
	char filebuf[128];
	int FILELENGTH=0;

	sprintf(filebuf, "%s/split.done", dir);
	fp = fopen(filebuf, "r");
	if (fp != NULL) {
		if ((fgets(tmpbuf, 255, fp)) != NULL) {
			*partnum = atoi(tmpbuf);
		}   
		if ((fgets(tmpbuf, 255, fp)) != NULL) {
			*lenth = atoi(tmpbuf);
		}   
		fclose(fp);
	} 

	print_data("partnum=%d, lenth=%d\n", *partnum, *lenth);
	return FILELENGTH;
}


/*************************************************************************/
/********************************THRIFT 主函数*****************************************/
/*************************************************************************/
class AdvertServiceHandler : virtual public AdvertServiceIf {
	public:
		AdvertServiceHandler() {
			// Your initialization goes here
		}

		void get(Advert& _return, const std::string& position, const std::string& product_id, const std::string& robot_id, const std::string& advert_name, const int8_t advert_part) 
		{
			print_data("--------get-------------\n");
			int i;
			string PID = product_id;
			string POSITION = position;
			print_data("pid=%s\n",product_id.c_str());
			string robotId = robot_id;
			string advertName = advert_name;
			int ADVERTPART = advert_part;
			print_data("reciveposition=%s, robot_id=%s\n", POSITION.c_str(), robotId.c_str());
			struct mysql_advert doAdvert;
			char mysqlId[1024];
			char mysqlIdtmp[1024];
			char itoabuf[8];
			char FILEDIR[128];
			char FILENAME[256];
			int ID=0;
			string NAME="";
			int TYPE=0; 
			int NUMBER=0; 
			int PARTNUMBER=0; 
			char NAMEPART[64];
			int LEN=0;
			string CONTENT="";
			int ENDFLAG=0;
			string DATE="";
			string TIME="";
			string MYSQLID="";
			string PUSH_PID="";
			Advert current_advert;


			print_data("advertName=%s, advert_part=%d\n", advertName.c_str(), ADVERTPART);
			if(!strcmp(advertName.c_str(), "none"))
			{
				/***************************************************************************/
				/**************************验证position对应的rootID是否改变***********************************/
				/***************************************************************************/
				mysqlId[0] = '\0';
				
				for(i=0;i<mysqlAdvert.size();i++)
				{
					if(mysqlAdvert.at(i).id == 0) break;
					//if(!strcmp(POSITION.c_str(), mysqlAdvert[i].position))
					if((!strcmp(POSITION.c_str(), mysqlAdvert.at(i).position)) || (!strcmp("all", mysqlAdvert.at(i).position))
					||(!strcmp("", mysqlAdvert.at(i).position)))
					{
						
						sprintf(itoabuf, "%d", mysqlAdvert.at(i).id);
						strcat(mysqlId, itoabuf);
						strcat(mysqlId, "-");
					}
				}
				if(strlen(mysqlId) == 0)
				{
					print_data("Notfind %s advert list !", position.c_str());
					return;
				}
				mysqlId[strlen(mysqlId) - 1] = '\0';
				print_data("mysqlId = %s\n", mysqlId);

				/***************************************************************************/
				/**************************判断是否需要传输新的广告***********************************/
				/***************************************************************************/
				if(!strcmp(robotId.c_str(), mysqlId))
				{
					print_data("robotId ==== mysqlId !");
					return;
				}

				strcpy(mysqlIdtmp, mysqlId);
				int current_id = get_advert_id((char *)robotId.c_str(), mysqlIdtmp);
				print_data("currentId = %d\n", current_id);
				if(current_id == -1) return;

				doAdvert.id = 0;
				FILEDIR[0] = '\0';
				for(i=0;i<mysqlAdvert.size();i++)
				{
					if(mysqlAdvert.at(i).id == 0) break;
					if(mysqlAdvert.at(i).id == current_id)
					{
						doAdvert.id = mysqlAdvert.at(i).id;
						strcpy(doAdvert.position, mysqlAdvert.at(i).position);
						strcpy(doAdvert.name, mysqlAdvert.at(i).name);
						print_data("none 时候mysqlAdvert.at(i).pid=%s\n",mysqlAdvert.at(i).pid);
						print_data("当广告名字等于none 时候的mysqladvertname=%s\n",mysqlAdvert.at(i).name);
						doAdvert.type = mysqlAdvert.at(i).type;
						doAdvert.number = mysqlAdvert.at(i).number;
						//doAdvert.partnumber = mysqlAdvert[i].partnumber;
						strcpy(doAdvert.url, mysqlAdvert.at(i).url);
						sprintf(FILEDIR, "%s/%s", ADVERT_HOME, doAdvert.name);
						get_advert_partnumber_length(FILEDIR, &doAdvert.partnumber, &doAdvert.len);
						strcpy(doAdvert.date, mysqlAdvert.at(i).date);
						strcpy(doAdvert.time, mysqlAdvert.at(i).time);
						doAdvert.pid[0]= '\0';
						strcpy(doAdvert.pid, mysqlAdvert.at(i).pid);
						print_data("当none时候赋值后的 doAdvert.pid=%s\n",doAdvert.pid);
						break;
					}
				}
				if(doAdvert.id == 0)
					return;
				if(strlen(FILEDIR) == 0)
					return;

				NAME = doAdvert.name;
				ID = doAdvert.id;
				TYPE = doAdvert.type;
				NUMBER = doAdvert.number;
				PARTNUMBER = doAdvert.partnumber;
				sprintf(NAMEPART, "%s.part0", NAME.c_str());
				//sprintf(FILEDIR, "%s/%s", ADVERT_HOME, NAME.c_str());
				DATE = doAdvert.date;
				TIME = doAdvert.time;
				MYSQLID = mysqlId;
				PUSH_PID=doAdvert.pid;

				print_data("MYSQLID=%s\n", MYSQLID.c_str());

				/***************************************************************************/
				/**************************传输新广告的part0文件***********************************/
				/***************************************************************************/
				//sprintf(FILENAME,"%s/%s.part0", FILEDIR, NAME.c_str());
				sprintf(FILENAME,"%s/%s", FILEDIR, NAMEPART);
				FILE *fileNew = fopen(FILENAME, "r");//打开文件
				if( fileNew == NULL )	{	print_data("%s file not exit !\n", FILENAME);	return;	}   
				if(doAdvert.len > 1024*1024) 
				{
					LEN = 1024*1024;
					ENDFLAG = 0;
				}
				else
				{
					LEN = doAdvert.len;
					ENDFLAG = 1;
				}
				print_data("new LEN = %d, ENDFLAG=%d\n", LEN, ENDFLAG);
				char *readbufnew = new char[LEN+1];
				fread(readbufnew, sizeof(char), LEN, fileNew); //文件读取到buf中
				fclose(fileNew);//关闭文件。

				string stringNew = "";
				stringNew.assign((char *)readbufnew, LEN);
				CONTENT = stringNew;
				delete readbufnew;
			}
			else  //not none
			{
				doAdvert.id = 0;
				FILEDIR[0] = '\0';
				for(i=0;i<mysqlAdvert.size();i++)
				{
					if(mysqlAdvert.at(i).id == 0) break;
					if((!strcmp(advertName.c_str(), mysqlAdvert.at(i).name)) \
							&& (!strcmp(POSITION.c_str(), mysqlAdvert.at(i).position) || !strcmp("all", mysqlAdvert.at(i).position)||!strcmp("", mysqlAdvert.at(i).position)))
					{
						doAdvert.id = mysqlAdvert.at(i).id;
						strcpy(doAdvert.position, mysqlAdvert.at(i).position);
						strcpy(doAdvert.name, mysqlAdvert.at(i).name);
						doAdvert.type = mysqlAdvert.at(i).type;
						doAdvert.number = mysqlAdvert.at(i).number;
						//doAdvert.partnumber = mysqlAdvert[i].partnumber;
						strcpy(doAdvert.url, mysqlAdvert.at(i).url);
						sprintf(FILEDIR, "%s/%s", ADVERT_HOME, doAdvert.name);
						get_advert_partnumber_length(FILEDIR, &doAdvert.partnumber, &doAdvert.len);
						strcpy(doAdvert.date, mysqlAdvert.at(i).date);
						strcpy(doAdvert.time, mysqlAdvert.at(i).time);
						doAdvert.pid[0]= '\0';
						strcpy(doAdvert.pid, mysqlAdvert.at(i).pid);
						break;
					}
				}
				if(doAdvert.id == 0)
					return;
				if(strlen(FILEDIR) == 0)
					return;

				NAME = doAdvert.name;
				ID = doAdvert.id;
				TYPE = doAdvert.type;
				NUMBER = doAdvert.number;
				PARTNUMBER = doAdvert.partnumber;
				PUSH_PID = doAdvert.pid;
				sprintf(NAMEPART, "%s.part%d", NAME.c_str(), ADVERTPART);
				//sprintf(FILEDIR, "%s/%s", ADVERT_HOME, NAME.c_str());
				DATE = doAdvert.date;
				TIME = doAdvert.time;
				MYSQLID = robotId.c_str();
				//sprintf(FILENAME,"%s/%s.part%d", FILEDIR, NAME.c_str(), ADVERTPART);
				sprintf(FILENAME,"%s/%s", FILEDIR, NAMEPART);
				FILE *fileOld = fopen(FILENAME, "r");//打开文件
				if( fileOld == NULL )	{	print_data("%s file not exit !\n", FILENAME);	return;	}   
				int partNumberOld = doAdvert.len/(1024*1024);
				int partRemainOld = doAdvert.len%(1024*1024);
				if(ADVERTPART < partNumberOld) 
				{
					LEN = 1024*1024;
					ENDFLAG = 0;
				}
				else if(ADVERTPART == partNumberOld)
				{
					LEN = partRemainOld;
					ENDFLAG = 1;
				}
				else 
					return;
				print_data("old LEN = %d, ENDFLAG=%d\n", LEN, ENDFLAG);
				char *readbufold = new char[LEN+1];
				fread(readbufold, sizeof(char), LEN, fileOld); //文件读取到buf中
				fclose(fileOld);//关闭文件。

				string stringOld = "";
				stringOld.assign((char *)readbufold, LEN);
				CONTENT = stringOld;
				delete readbufold;
			}
			/*********************精准推送判断pid是否为空**************/
			print_data("PUsh_pid=%s\n",PUSH_PID.c_str());
			print_data("PID=%s\n",PID.c_str());
			print_data("PUSH_PID.size()=%d\n",PUSH_PID.size());
			if(PUSH_PID.size() < 14)
			{
				current_advert.add.name = NAMEPART;
				current_advert.add.id = ID;
				print_data("ID=%d\n",ID);
				current_advert.add.type = TYPE;
				current_advert.add.number = NUMBER;
				current_advert.add.partnumber = PARTNUMBER;
				current_advert.add.len = CONTENT.length();
				current_advert.add.content = CONTENT;
				current_advert.add.endflag = ENDFLAG;
				current_advert.add.date = DATE;
				current_advert.add.time = TIME;
				current_advert.mysql_id = MYSQLID;

			}else
			{
				/**********如果相等的想等的话修改数据库状态**************/
				if(!strcmp(PID.c_str(),PUSH_PID.c_str()))
				{
				print_data("数据库pid=%s ,穿过来的pid=%s\n",PUSH_PID.c_str(),PID.c_str());
					current_advert.add.name = NAMEPART;
					current_advert.add.id = ID;
					current_advert.add.type = TYPE;
					current_advert.add.number = NUMBER;
					current_advert.add.partnumber = PARTNUMBER;
					current_advert.add.len = CONTENT.length();
					current_advert.add.content = CONTENT;
					current_advert.add.endflag = ENDFLAG;
					current_advert.add.date = DATE;
					current_advert.add.time = TIME;
					current_advert.mysql_id = MYSQLID;
		 			print_data("ssssID=%d\n",ID);
             				

				}
				else
				{
					current_advert.add.name = NAMEPART;
					current_advert.add.id = ID;
					current_advert.add.partnumber = -1;
					current_advert.add.endflag = 1;
					current_advert.mysql_id = MYSQLID;
				}	
			}
			_return = current_advert;
			_return.__isset.add = true;
		}
};

//int main(int argc, char **argv) {
void * process_handleThrift(void *parg)
{
	int port = 19094;
	shared_ptr<AdvertServiceHandler> handler(new AdvertServiceHandler());
	shared_ptr<TProcessor> processor(new AdvertServiceProcessor(handler));

#ifdef THREAD_POOL_SERVER
	shared_ptr<TProtocolFactory> protocolFactory(new TCompactProtocolFactory());    
	shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());    
	shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));    

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start advert server...\n");    

	TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);    
	server.serve();    
#else
	shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start advert server...\n");    

	TNonblockingServer server(processor,protocolFactory,port,threadManager);
	server.serve();    
#endif

	return NULL;
};

