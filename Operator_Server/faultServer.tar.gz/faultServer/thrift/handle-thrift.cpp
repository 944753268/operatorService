/**************************************OW_ARRAY_SIZE***/
/****************jason_modify*************/
#include <string>  
#include <iostream>   
#include "FaultService.h"    
#include <config.h>    
#include <vector>
#include "global.h"
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>
#include <transport/TServerSocket.h>
#include <transport/TBufferTransports.h>
#include <concurrency/ThreadManager.h>
#include <concurrency/PosixThreadFactory.h>
#include <thrift/concurrency/ThreadManager.h>  
#include <thrift/concurrency/PosixThreadFactory.h>  
#include <thrift/server/TThreadPoolServer.h>  
#include <thrift/server/TThreadedServer.h>  
#include <thrift/server/TNonblockingServer.h>  
#include <server/TThreadPoolServer.h>
#include <server/TThreadedServer.h>
#include <protocol/TCompactProtocol.h>    
#include <server/TSimpleServer.h>    
#include <transport/TServerSocket.h>    
#include <transport/TBufferTransports.h>    
#include <concurrency/ThreadManager.h>    
#include <concurrency/PosixThreadFactory.h>    
#include <server/TThreadPoolServer.h>    
#include <server/TThreadedServer.h>

#define  THREAD_POOL_SERVER 1

using namespace ::apache::thrift;    
using namespace ::apache::thrift::protocol;    
using namespace ::apache::thrift::transport;    
using namespace ::apache::thrift::server;    
using namespace ::apache::thrift::concurrency;    

using boost::shared_ptr;  
using namespace std;   

class FaultServiceHandler : virtual public FaultServiceIf {
	public:
		FaultServiceHandler() {
			// Your initialization goes here
		}

		void put(const std::string& pid,  const std::string& position,  const std::string& name,  const std::string& tel,  const std::string& qq,  const std::string& email,  const std::string& address,  const std::string& selltime,  const std::string& code,  const std::string& desc,  const std::string& comtime){		

			print_data("name=%s, tel=%s\n", name.c_str(), tel.c_str());
			char p_osition[32];
			char p_id[32];
			char n_ame[32];
			char t_el[32];
			char u_serqq[32];
			char e_mail[128];
			char a_ddress[256];
			char s_ell_date[32];
			char c_ode[32];
			char d_esc[256];
			char c_omtime[32];
			char status[32]="0";

			strcpy(p_id, pid.c_str());
			strcpy(p_osition, position.c_str());
			strcpy(n_ame, name.c_str());
			strcpy(t_el, tel.c_str());
			strcpy(u_serqq, qq.c_str());
			strcpy(e_mail, email.c_str());
			strcpy(a_ddress, address.c_str());
			strcpy(s_ell_date, selltime.c_str());
			strcpy(c_ode, code.c_str());
			strncpy(d_esc, desc.c_str(), 255);
			strcpy(c_omtime, comtime.c_str());

			if((strlen(p_id) > 3) && (strlen(p_osition) > 3)){
				/*************************************************************/
				/**********************插入userinfo数据库*********************/
				insert_mysql_userinfo(p_osition, p_id, n_ame, t_el, u_serqq, e_mail, a_ddress,  s_ell_date);
				/**************************************************************/
				/*************将提交的数据插入fault_list数据库*****************/
				intsert_mysql_fault_code_list(p_id, p_osition, c_omtime, c_ode, status, d_esc);
			}
			print_data("put\n");
		}

		void get(std::vector<History> & _return,  const std::string& position,  const std::string& pid) {
			char current_productId[32];
			strcpy(current_productId,  pid.c_str());
			print_data("当前的pid是:%s\n",current_productId);
			vector<History> vectorr;
			memset(&vectorr,  0,  sizeof(vector<History>));
			print_data("开始获取数据get_mysql_fault_code\n");
			get_mysql_fault_code(vectorr,current_productId);
			_return=vectorr;
			vectorr.clear();
			vectorr.swap(vectorr);
			print_data("get\n");
		}
};

//int main(int argc,  char **argv) {
void * process_handleThrift(void *parg)
{
	int port = 19095;
	shared_ptr<FaultServiceHandler> handler(new   FaultServiceHandler());    
	shared_ptr<TProcessor> processor(new FaultServiceProcessor(handler)); 

#ifdef THREAD_POOL_SERVER	
	shared_ptr<TProtocolFactory> protocolFactory(new TCompactProtocolFactory());    
	shared_ptr<TTransportFactory> transportFactory(new TBufferedTransportFactory());    
	shared_ptr<TServerTransport> serverTransport(new TServerSocket(port));    

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start fault server...\n");    

	TThreadPoolServer server(processor, serverTransport, transportFactory, protocolFactory, threadManager);    
	server.serve();    
#else
	shared_ptr<TProtocolFactory> protocolFactory(new TBinaryProtocolFactory());    

	shared_ptr<ThreadManager> threadManager = ThreadManager::newSimpleThreadManager(100);    
	shared_ptr<PosixThreadFactory> threadFactory = shared_ptr<PosixThreadFactory>(new PosixThreadFactory());    
	threadManager->threadFactory(threadFactory);    
	threadManager->start();    
	printf("start fault server...\n");    

	TNonblockingServer server(processor,protocolFactory,port,threadManager);
	server.serve();    
#endif

	return NULL;
}

