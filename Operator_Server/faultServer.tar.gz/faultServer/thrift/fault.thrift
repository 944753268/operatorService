struct	History{
	1: string time,
	2: string code,
	3: string status,
}

service FaultService{
	void put(
			1:string pid,
			2:string position,
			3:string name,
			4:string tel,
			5:string qq,
			6:string email,
			7:string address,
			8:string selltime,
			9:string code,
			10:string desc,
			11:string comtime,
			)

	list<History> get(
			1:string position,
			2:string pid,
			)
}
