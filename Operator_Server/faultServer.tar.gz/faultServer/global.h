/******************************************************
  THIS IS MADE BY:LISHELIN
  E-MAIL:lishelin0505@163.com
CREATE:2015-04-03 FIRST
DECLARE:THIS IS FOR THE DEVICE OF 805AE-1 OF NEWABEL
COMPANY URL:WWW.NEWABEL.COM
 ******************************************************/
#ifndef global_H
#define global_H
#include "FaultService.h"
extern int do_exit;
//extern struct send_data odbcData, eventData;
//extern int deviceListNum;
//extern struct device_list deviceList[1024];

#define SQL_RET_NULL 0X0001
#define SQL_RET_ERR 0X0002
#define SQL_RET_WRITE 0X0004
#define SQL_RET_READ 0X0008

#if 0
struct mysql_advert {
	int id;
	char position[32];
	char name[32];
	int type;
	int number;
	int partnumber;
	char url[128];
	int len;
	char date[32];
	char time[32];
	int sendflag;
};
# endif
//extern struct mysql_advert mysqlAdvert[100];
//extern char ADVERT_HOME[];


void print_data(const char *fmt,...);
//int wait_odbc_timeOut(int second);
void initOdbc(void);
//void * process_handleOdbc(void *parg);
void * process_handleThrift(void *parg);
//int send_odbc_message(status_handle status, int datalen, unsigned char *data, int devtype);
//void exit_thrift(void);
void endOdbc(void);
void insert_mysql_userinfo(char *position,char *pid,char *username,char *usertel,char *userqq,char *usereamil, char *useraddress,char *sell_date);
void  get_mysql_fault_code(std::vector<History>  &vec,char *pid);
void intsert_mysql_fault_code_list(char *pid,char *position, char *date ,char *code, char *status ,char *desc);

void initJubing();
void endJubing();


#endif
