#include <sql.h>
#include <sqltypes.h>
#include <sqlext.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "FaultService.h"
#include "global.h"
using namespace std;
//odbc
/* 检测返回代码是否为成功标志，当为成功标志返回TRUE，否则返回FALSE */
#define RC_SUCCESSFUL(rc)  ((rc) == SQL_SUCCESS || (rc) == SQL_SUCCESS_WITH_INFO)
/* 检测返回代码是否为失败标志，当为失败标志返回TRUE，否则返回FALSE */
#define RC_NOTSUCCESSFUL(rc) (!(RC_SUCCESSFUL(rc)))

#define ROW_ARRAY_SIZE 100

SQLHENV      henv;  /* 环境句柄 */
SQLHDBC      hdbc;  /* 连接句柄 */
SQLHSTMT     hsmt;  /* 语句句柄 */
SQLHSTMT     hsmtinsertfault;  /* 语句句柄 */
SQLHSTMT     hsmtuser;  /* 语句句柄 */
SQLHSTMT     hsmtinsert;  /* 语句句柄 */
static int odbc_reconnect_flag=0;

void update_mysql_userinfo(char *position,char *pid,char *username,char *usertel,char *userqq,char *useremail, char *useraddress,char *sell_date);
int get_dmserver_dsn_usrname_passwd(char *resdsn, char *resname, char *respasswd)
{
	FILE *fp;
	char tmpValue[32];
	char tmpbuf[256];
	int tlen, len;
	char *pos1, *pos2;

	fp=fopen("/etc/faultServer.conf", "r");
	if (fp != NULL)
	{
		while ((fgets(tmpbuf, 255, fp)) != NULL)
		{
			tlen = strlen(tmpbuf);
			if(tmpbuf[tlen - 1] == '\n')  tmpbuf[tlen - 1]='\0';

			if((pos1=strstr(tmpbuf, "[")) != NULL)
			{
				pos1 += 1;
				pos2 = strstr(pos1, "]");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resdsn, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "username=")) != NULL)
			{
				pos1 += 9; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(resname, tmpValue);
			}
			else if((pos1=strstr(tmpbuf, "passwd=")) != NULL)
			{
				pos1 += 7; 
				pos2 = strstr(pos1, ";");
				len = pos2 - pos1;
				strncpy(tmpValue, pos1, len);
				tmpValue[len] = '\0';
				//print_data("tmpValue=%s \n",tmpValue);
				strcpy(respasswd, tmpValue);
				break;
			}
		}

		fclose(fp);
		fp=NULL;
	}
	else
		print_data("open /etc/faultServer.conf failed \n");

	return 0;
}


void initJubing()
{
	char dsn[32];
	char usrname[32];
	char passwd[32];
	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);

	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsertfault);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtuser);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);
}


void initOdbc(void)
{
	char dsn[32];
	char usrname[32];
	char passwd[32];

	get_dmserver_dsn_usrname_passwd(dsn, usrname, passwd);
	print_data("dsn=%s, usrname=%s, passwd=%s\n", dsn, usrname, passwd);

	/* 申请一个环境句柄  */
	SQLAllocHandle(SQL_HANDLE_ENV, NULL, &henv);
	/* 设置环境句柄的ODBC版本  */
	SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_INTEGER);
/*	SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);
	SQLConnect(hdbc, (SQLCHAR *)dsn, SQL_NTS, (SQLCHAR *)usrname, SQL_NTS, (SQLCHAR *)passwd, SQL_NTS);*/
	/* 申请一个语句句柄  */
/*	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmt);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsertfault);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtuser);
	SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hsmtinsert);*/
	//ping_modify
	initJubing();
}


void endJubing(){
	/* 释放语句句柄  */
	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsertfault);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtuser);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);

	/* 断开与数据源之间的连接  */
	SQLDisconnect(hdbc);
	/* 释放连接句柄  */
	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
}


void endOdbc(void)
{
	/* 释放语句句柄  */
/*	SQLFreeHandle(SQL_HANDLE_STMT, hsmt);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsertfault);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtuser);
	SQLFreeHandle(SQL_HANDLE_STMT, hsmtinsert);*/


	/* 断开与数据源之间的连接  */
	//SQLDisconnect(hdbc);
	/* 释放连接句柄  */
//	SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	//ping_modify
	endJubing();
	/* 释放环境句柄  */
	SQLFreeHandle(SQL_HANDLE_ENV, henv);
}


void update_mysql_userinfo(char *position,char *pid,char *username,char *usertel,char *userqq,char *useremail, char *useraddress,char *sell_date)
{
	char cmdbuf [256];
	SQLRETURN rc;
	sprintf( cmdbuf,"UPDATE userinfo_%s_list SET\
			name='%s',\
			telephone='%s',\
			qq_wechat='%s',\
			email='%s',\
			address='%s',\
			sell_date='%s' where product_id='%s';",\
			position, username, usertel, userqq, useremail, useraddress, sell_date, pid);
	rc=SQLExecDirect( hsmtuser, (SQLCHAR *)cmdbuf, SQL_NTS);
	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		//ping_modify
		//return;
	}
	SQLCloseCursor(hsmtuser);
}


void insert_mysql_userinfo(char *position,char *pid,char *username,char *usertel,char *userqq,char *useremail, char *useraddress,char *sell_date)
{
	char cmdbuf[256] ;
	SQLRETURN rc;
	sprintf(cmdbuf,"INSERT INTO userinfo_%s_list values ('%s','%s','%s','%s','%s','%s','%s');",\
			position, pid, username, usertel,userqq,useremail,useraddress,sell_date);
	rc = SQLExecDirect( hsmtinsert, (SQLCHAR *)cmdbuf, SQL_NTS);

	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		/**************插入数据库失败，那么替换原有的那一条数据*************************/
		print_data("插入userinfo数据库失败，修改userinfo数据库\n");
		update_mysql_userinfo(position,pid,username,usertel,userqq,useremail, useraddress,sell_date);
		//ping_modify
		//return;
	}
	SQLCloseCursor(hsmtinsert);
}


void intsert_mysql_fault_code_list(char *pid,char *position, char *date ,char *code, char *status ,char *desc)
{
	char cmdbuf[256] ;
	SQLRETURN rc;
	sprintf( cmdbuf,"INSERT INTO fault_code_list(product_id,position,date,fault_code,status,des) values ('%s','%s','%s','%s','%s','%s');",pid, position, date, code,status, desc);
	rc = SQLExecDirect( hsmtinsertfault, (SQLCHAR *)cmdbuf, SQL_NTS);

	if(rc == SQL_INVALID_HANDLE)
	{
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}
	if ( rc != SQL_SUCCESS )
	{
		//ping_modify
		//return;
	}
	SQLCloseCursor(hsmtinsertfault);
	print_data("插入fault_code_list成功\n");
}



/*************************根据pid读取数据库********************************/
void  get_mysql_fault_code(std::vector<History> &vectorr,char *pid){
	unsigned int i;
	char cmdbuf[256];
	History history;
	history.time="";
	history.code="";
	history.status="";

	struct history_info{
		SQLCHAR date[32];
		SQLLEN dateInd;
		SQLCHAR code[32];
		SQLLEN codeInd;
		SQLCHAR status[32];
		SQLLEN statusInd;
	};
	struct history_info OrderInfoArray[ROW_ARRAY_SIZE];
	SQLUINTEGER NumRowsFetched;
	SQLUSMALLINT RowStatusArray[ROW_ARRAY_SIZE];
	SQLRETURN rc;

	sprintf( cmdbuf, "SELECT date,fault_code,status  FROM fault_code_list WHERE product_id='%s';",pid);
	print_data("%s\n", cmdbuf);
	SQLPrepare(hsmt,(SQLCHAR *)cmdbuf, SQL_NTS);
	print_data("001******************\n");


	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_BIND_TYPE,(SQLPOINTER *)sizeof(history_info),0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_ARRAY_SIZE,(SQLPOINTER *)ROW_ARRAY_SIZE,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROW_STATUS_PTR,RowStatusArray,0);
	SQLSetStmtAttr(hsmt,SQL_ATTR_ROWS_FETCHED_PTR,&NumRowsFetched,0);

	SQLBindCol(hsmt,1,SQL_C_CHAR,OrderInfoArray[0].date,sizeof(OrderInfoArray[0].date),&OrderInfoArray[0].dateInd);		      
	SQLBindCol(hsmt,2,SQL_C_CHAR,OrderInfoArray[0].code,sizeof(OrderInfoArray[0].code),&OrderInfoArray[0].codeInd);
	SQLBindCol(hsmt,3,SQL_C_CHAR,OrderInfoArray[0].status,sizeof(OrderInfoArray[0].status),&OrderInfoArray[0].statusInd);
	print_data("002****************\n");

	rc=SQLExecute(hsmt);
	if(rc == SQL_INVALID_HANDLE)
	{
		printf("\n数据库链接失败\n");
		odbc_reconnect_flag = 1;
		endJubing();
		initJubing();
		return;
	}

	if ( rc != SQL_SUCCESS )
	{
		//ping_modify
		endJubing();
		initJubing();
		return;
	}
	print_data("003***************\n");
	//ping_modify
	while (( rc = SQLFetchScroll(hsmt, SQL_FETCH_NEXT, 0 )) != SQL_NO_DATA )
	{
		for ( i = 0 ;i< NumRowsFetched; i++ )
		{

			if (RowStatusArray[ i ] == SQL_ROW_SUCCESS||RowStatusArray[i] == SQL_ROW_SUCCESS_WITH_INFO )
			{

				if (OrderInfoArray[i].dateInd == SQL_NULL_DATA)//1
				{
					print_data("date=NULL\t");
				}
				else
				{
					print_data("第%d次循环：\n",i);
					print_data("%s\n ", OrderInfoArray[i].date); 
				}
				if (OrderInfoArray[i].codeInd == SQL_NULL_DATA)//2
					print_data("code=NULL\n");
				else
					print_data("%s\n ", OrderInfoArray[i].code); 

				if (OrderInfoArray[i].statusInd == SQL_NULL_DATA)//3
					print_data("status=NULL\t");
				else
					print_data("%s\n ", OrderInfoArray[i].status);
				history.time = (char *)OrderInfoArray[i].date;
				history.code = (char *)OrderInfoArray[i].code;
				history.status = (char *)OrderInfoArray[i].status;


			}
			vectorr.push_back(history);

		}
	}

	if(vectorr.empty()){
		history.time="none";
		history.code="none";
		history.status="none";
		vectorr.push_back(history);
	}

	SQLCloseCursor(hsmt);

}
